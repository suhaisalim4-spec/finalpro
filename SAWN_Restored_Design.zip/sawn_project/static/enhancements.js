const region = document.querySelector('#announcementRegion');

if (region) {
  const refreshAnnouncement = async () => {
    if (document.hidden || region.contains(document.activeElement) || region.matches(':hover')) return;
    try {
      const response = await fetch(region.dataset.source, { cache: 'no-store' });
      if (!response.ok || response.redirected || region.contains(document.activeElement) || region.matches(':hover')) return;
      const html = (await response.text()).trim();
      if (region.innerHTML.trim() === html) return;
      const paused = region.querySelector('#pauseTicker')?.checked;
      region.innerHTML = html;
      const checkbox = region.querySelector('#pauseTicker');
      if (checkbox) checkbox.checked = Boolean(paused);
    } catch {
      // Keep the current announcement if the refresh fails.
    }
  };
  window.setInterval(refreshAnnouncement, 10000);
}

const searchForm = document.querySelector('.globalSearch');
if (searchForm) {
  const input = searchForm.querySelector('input');
  const suggestions = searchForm.querySelector('.searchResults');
  let searchTimer;
  let searchRequest;

  input.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchRequest?.abort();
    suggestions.hidden = true;
    const query = input.value.trim();
    if (query.length < 2) return;

    searchTimer = window.setTimeout(async () => {
      searchRequest = new AbortController();
      try {
        const url = new URL(searchForm.dataset.suggestions, location.origin);
        url.searchParams.set('q', query);
        const response = await fetch(url, { signal: searchRequest.signal });
        if (!response.ok || response.redirected) return;
        const matches = await response.json();
        if (input.value.trim() !== query || !searchForm.contains(document.activeElement)) return;
        suggestions.replaceChildren(...matches.map(({ title, url }) => {
          const link = document.createElement('a');
          link.href = url;
          link.textContent = title;
          return link;
        }));
        suggestions.hidden = matches.length === 0;
      } catch {
        // The regular search form remains available.
      }
    }, 220);
  });
  searchForm.addEventListener('focusout', event => {
    if (!searchForm.contains(event.relatedTarget)) suggestions.hidden = true;
  });
  searchForm.addEventListener('keydown', event => {
    if (event.key === 'Escape') suggestions.hidden = true;
  });
}

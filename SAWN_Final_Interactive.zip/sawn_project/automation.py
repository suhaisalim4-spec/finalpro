"""Weekly reports and daily SQLite backups, using only the Python standard library."""
import json
import logging
import os
import sqlite3
import threading
from datetime import date, datetime, timedelta
from pathlib import Path
from domain import today, LOCAL_TZ


def report_data(conn, start):
    if isinstance(start,str): start=date.fromisoformat(start)
    end=start+timedelta(days=7)
    bounds=(start.isoformat(),end.isoformat())
    repairs=[dict(r) for r in conn.execute('''SELECT t.*,d.asset_tag,d.name device_name,
        COALESCE(u.display_name,t.technician) assignee FROM tickets t JOIN devices d ON d.id=t.device_id
        LEFT JOIN users u ON u.id=t.assigned_to WHERE date(t.created_at,'+4 hours')>=? AND date(t.created_at,'+4 hours')<? ORDER BY t.id''',bounds)]
    completed=[dict(r) for r in conn.execute('''SELECT t.*,d.asset_tag,d.name device_name,
        COALESCE(u.display_name,t.technician) assignee FROM tickets t JOIN devices d ON d.id=t.device_id
        LEFT JOIN users u ON u.id=t.assigned_to WHERE date(t.completed_at,'+4 hours')>=? AND date(t.completed_at,'+4 hours')<? ORDER BY t.completed_at''',bounds)]
    events=[dict(r) for r in conn.execute('''SELECT e.*,d.asset_tag,u.display_name actor FROM ticket_events e
        JOIN tickets t ON t.id=e.ticket_id JOIN devices d ON d.id=t.device_id LEFT JOIN users u ON u.id=e.actor_id
        WHERE date(e.created_at,'+4 hours')>=? AND date(e.created_at,'+4 hours')<? AND e.event_type!='legacy' ORDER BY e.id''',bounds)]
    tasks=[dict(r) for r in conn.execute('''SELECT t.*,u.display_name FROM tasks t JOIN users u ON u.id=t.assigned_to
        WHERE date(t.due_date)>=? AND date(t.due_date)<? ORDER BY t.due_date,t.id''',bounds)]
    upkeep=[dict(r) for r in conn.execute('''SELECT s.*,d.asset_tag FROM schedules s JOIN devices d ON d.id=s.device_id
        WHERE s.is_active=1 AND s.due_date>=? AND s.due_date<? ORDER BY s.due_date''',bounds)]
    services=[dict(r) for r in conn.execute('SELECT m.*,d.asset_tag,d.name device_name,u.display_name technician FROM maintenance_records m JOIN devices d ON d.id=m.device_id LEFT JOIN users u ON u.id=m.performed_by WHERE m.performed_on>=? AND m.performed_on<? ORDER BY m.performed_on,m.id',bounds)]
    device_count=conn.execute("SELECT count(*) FROM devices WHERE date(created_at,'+4 hours')>=? AND date(created_at,'+4 hours')<?",bounds).fetchone()[0]
    return dict(start=bounds[0],end=(end-timedelta(days=1)).isoformat(),devices=device_count,
                repairs=repairs,completed=completed,events=events,tasks=tasks,upkeep=upkeep,services=services)


def generate_due_reports(conn, current_day=None):
    current_day=current_day or today()
    this_week=current_day-timedelta(days=current_day.weekday())
    earliest=conn.execute("SELECT min(day) FROM (SELECT date(created_at,'+4 hours') day FROM tickets UNION ALL SELECT date(created_at,'+4 hours') FROM devices)").fetchone()[0]
    first=date.fromisoformat(earliest) if earliest else this_week-timedelta(days=7)
    first=first-timedelta(days=first.weekday())
    first=min(first,this_week-timedelta(days=7))
    created=0
    while first<this_week:
        if not conn.execute('SELECT 1 FROM weekly_reports WHERE week_start=?',(first.isoformat(),)).fetchone():
            payload=report_data(conn,first)
            cursor=conn.execute('INSERT OR IGNORE INTO weekly_reports(week_start,week_end,generated_at,payload) VALUES (?,?,?,?)',
                               (payload['start'],payload['end'],datetime.now(LOCAL_TZ).isoformat(timespec='seconds'),json.dumps(payload,ensure_ascii=False)))
            created+=cursor.rowcount
        first+=timedelta(days=7)
    conn.commit()
    return created


def backup_directory(database):
    return Path(os.environ.get('SAWN_BACKUP_DIR',str(Path(database).parent/'instance'/Path(database).stem/'backups')))


def daily_backup(database,current_day=None):
    current_day=current_day or today()
    directory=backup_directory(database)
    directory.mkdir(parents=True,exist_ok=True)
    target=directory/f'sawn-backup-{current_day.isoformat()}.sqlite3'
    if target.exists(): return target
    temporary=directory/(target.name+'.partial')
    source=sqlite3.connect(database,timeout=10)
    destination=sqlite3.connect(temporary)
    try:
        source.backup(destination)
        if destination.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
            raise RuntimeError('Backup integrity check failed')
    finally:
        destination.close();source.close()
    temporary.replace(target)
    con=sqlite3.connect(database,timeout=10)
    try:
        con.execute('INSERT OR IGNORE INTO backup_log(filename,created_at) VALUES (?,?)',(target.name,datetime.now(LOCAL_TZ).isoformat(timespec='seconds')))
        con.commit()
    finally:con.close()
    return target


def run_due(database,current_day=None):
    con=sqlite3.connect(database,timeout=10)
    con.row_factory=sqlite3.Row
    try: count=generate_due_reports(con,current_day)
    finally:con.close()
    path=daily_backup(database,current_day)
    return count,path


_worker_lock=threading.Lock()

def before_upgrade_backup(database):
    database=Path(database)
    if not database.is_file() or not database.stat().st_size:return None
    source=sqlite3.connect(database,timeout=10)
    try:
        columns={row[1] for row in source.execute('PRAGMA table_info(tickets)')}
        if not columns or 'maintenance_actions' in columns:return None
        directory=backup_directory(database)
        directory.mkdir(parents=True,exist_ok=True)
        target=directory/f'sawn-before-upgrade-final-{today().isoformat()}.sqlite3'
        if not target.exists():
            destination=sqlite3.connect(target)
            try:source.backup(destination)
            finally:destination.close()
        return target
    finally:source.close()


def start_worker(app,database):
    if app.config.get('TESTING'):return
    with _worker_lock:
        if app.extensions.get('sawn_worker'):return
        stop=threading.Event()
        def work():
            while not stop.is_set():
                try:run_due(database)
                except Exception:logging.getLogger(__name__).exception('SAWN scheduled report/backup failed')
                stop.wait(60)
        thread=threading.Thread(target=work,name='sawn-weekly-reports',daemon=True)
        app.extensions['sawn_worker']=(thread,stop)
        thread.start()

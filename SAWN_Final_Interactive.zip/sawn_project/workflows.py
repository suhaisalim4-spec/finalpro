"""Repair timelines, supervisor accounts, report archives, and backup downloads."""
import csv
import io
import json
import re
import sqlite3
import tempfile
from datetime import date
from pathlib import Path
from flask import g, request, session, render_template, redirect, url_for, flash, send_file
from werkzeug.security import generate_password_hash
from domain import bounded, technician, event, today
from automation import backup_directory, daily_backup, generate_due_reports, report_data


def register_workflows(app,db,login_required,admin_required,log,notify,visibility,database):
    @app.get('/tickets/<int:id>')
    @login_required
    def ticket_detail(id):
        scope,params=visibility('t')
        row=db().execute('''SELECT t.*,d.asset_tag,d.name device_name,COALESCE(u.display_name,t.technician) assignee,
            c.display_name creator FROM tickets t JOIN devices d ON d.id=t.device_id
            LEFT JOIN users u ON u.id=t.assigned_to LEFT JOIN users c ON c.id=t.created_by
            WHERE t.id=? AND '''+scope,(id,)+params).fetchone()
        if not row:return 'Ticket not found or access denied',404
        history=db().execute('''SELECT e.*,u.display_name actor,a.display_name assignee FROM ticket_events e
            LEFT JOIN users u ON u.id=e.actor_id LEFT JOIN users a ON a.id=e.new_assigned_to
            WHERE e.ticket_id=? ORDER BY e.id''',(id,)).fetchall()
        choices=db().execute("SELECT id,display_name FROM users WHERE role='technician' AND is_active=1 ORDER BY display_name").fetchall()
        can_update=g.user['role']=='admin' or (g.user['role']=='technician' and row['assigned_to']==g.user['id'])
        return render_template('ticket_detail.html',ticket=row,history=history,technicians=choices,can_update=can_update)

    @app.post('/tickets/<int:id>/assign')
    @admin_required
    def assign_ticket(id):
        row=db().execute('SELECT * FROM tickets WHERE id=?',(id,)).fetchone()
        if not row:return 'Not found',404
        try:
            if row['status']=='مكتمل':raise ValueError('البلاغ مكتمل؛ يجب إعادة فتحه قبل تغيير الفني')
            person=technician(db(),request.form.get('assigned_to'),True)
            if person['id']!=row['assigned_to']:
                note=f"إسناد الفني: {row['technician'] or 'غير محدد'} ← {person['display_name']}"
                db().execute('UPDATE tickets SET assigned_to=?,technician=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(person['id'],person['display_name'],id))
                event(db(),id,g.user['id'],'assigned',old_assignee=row['assigned_to'],new_assignee=person['id'],note=note)
                notify(person['id'],'بلاغ صيانة مسند إليك',row['issue'],'/tickets/'+str(id))
                log('ticket_assigned',str(id));db().commit();flash('تم تحديث الفني وإشعاره','success')
        except ValueError as exc:flash(str(exc),'error')
        return redirect(url_for('ticket_detail',id=id))

    @app.post('/tickets/<int:id>/notes')
    @login_required
    def ticket_note(id):
        scope,params=visibility('t')
        row=db().execute('SELECT t.* FROM tickets t WHERE t.id=? AND '+scope,(id,)+params).fetchone()
        if not row:return 'Access denied',403
        try:
            note=bounded(request.form.get('note'),'ملاحظة المتابعة',3,3000)
            event(db(),id,g.user['id'],'note',note=note)
            db().execute('UPDATE tickets SET updated_at=CURRENT_TIMESTAMP WHERE id=?',(id,))
            log('ticket_note',str(id));db().commit();flash('تم حفظ الملاحظة في السجل','success')
        except ValueError as exc:flash(str(exc),'error')
        return redirect(url_for('ticket_detail',id=id)+'#repairHistory')

    @app.route('/users',methods=['GET','POST'])
    @admin_required
    def users():
        if request.method=='POST':
            try:
                username=bounded(request.form.get('username'),'اسم الدخول',3,40)
                if not re.fullmatch(r'[A-Za-z0-9_.-]+',username):raise ValueError('اسم الدخول: استخدم حروفًا إنجليزية وأرقامًا أو . _ -')
                display=bounded(request.form.get('display_name'),'اسم الموظف',2,100)
                password=bounded(request.form.get('password'),'كلمة المرور',10,128)
                role=request.form.get('role','employee')
                if role not in ('admin','technician','employee'):raise ValueError('الدور غير صالح')
                db().execute('INSERT INTO users(username,password_hash,display_name,role) VALUES (?,?,?,?)',(username,generate_password_hash(password),display,role))
                log('user_created',username);db().commit();flash('تم إنشاء الحساب','success')
            except ValueError as exc:flash(str(exc),'error')
            except sqlite3.IntegrityError:db().rollback();flash('اسم الدخول مستخدم بالفعل','error')
            return redirect(url_for('users'))
        people=db().execute('SELECT id,username,display_name,role,is_active FROM users ORDER BY id').fetchall()
        return render_template('users.html',people=people)

    @app.post('/users/<int:id>/active')
    @admin_required
    def user_active(id):
        row=db().execute('SELECT * FROM users WHERE id=?',(id,)).fetchone()
        if not row:return 'Not found',404
        if id==g.user['id']:return 'Cannot deactivate your own account',400
        if row['is_active'] and db().execute("SELECT 1 FROM tickets WHERE assigned_to=? AND status!='مكتمل'",(id,)).fetchone():
            flash('أعد إسناد البلاغات المفتوحة قبل إيقاف حساب الفني','error')
        else:
            db().execute('UPDATE users SET is_active=? WHERE id=?',(0 if row['is_active'] else 1,id))
            log('user_active_changed',str(id));db().commit();flash('تم تحديث الحساب','success')
        return redirect(url_for('users'))

    @app.get('/reports/archive/<int:id>')
    @admin_required
    def report_archive(id):
        row=db().execute('SELECT * FROM weekly_reports WHERE id=?',(id,)).fetchone()
        if not row:return 'Report not found',404
        try:payload=json.loads(row['payload'])
        except (ValueError,TypeError):return 'Report snapshot is invalid',500
        saved=db().execute('SELECT id,week_start,week_end,generated_at FROM weekly_reports ORDER BY week_start DESC LIMIT 52').fetchall()
        return render_template('reports.html',report=payload,saved=saved,snapshot=row)

    @app.get('/reports/export')
    @admin_required
    def reports_export():
        snapshot=request.args.get('id',type=int)
        if snapshot:
            row=db().execute('SELECT * FROM weekly_reports WHERE id=?',(snapshot,)).fetchone()
            if not row:return 'Report not found',404
            payload=json.loads(row['payload'])
        else:
            try:start=date.fromisoformat(request.args.get('start',''))
            except ValueError:return 'Invalid week',400
            payload=report_data(db(),start)
        output=io.StringIO();writer=csv.writer(output)
        writer.writerow(['نوع السجل','رقم البلاغ','الجهاز','المشكلة','الحالة','الفني','ملخص الإصلاح'])
        def safe(value):
            value=str(value or '')
            return "'"+value if value.startswith(('=','+','-','@')) else value
        for kind,rows in [('بلاغ جديد',payload['repairs']),('إصلاح مكتمل',payload['completed'])]:
            for row in rows:writer.writerow([safe(v) for v in [kind,row['id'],row['asset_tag'],row['issue'],row.get('status','مكتمل'),row.get('assignee'),row.get('resolution')]])
        response=send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),mimetype='text/csv',as_attachment=True,download_name=f"sawn-week-{payload['start']}.csv")
        response.headers['Cache-Control']='no-store'
        return response

    @app.get('/backups')
    @admin_required
    def backups():
        directory=backup_directory(database())
        rows=[dict(row) for row in db().execute('SELECT * FROM backup_log ORDER BY id DESC LIMIT 30') if (directory/row['filename']).is_file()]
        return render_template('backups.html',rows=rows)

    @app.get('/backups/download')
    @admin_required
    def backup_download():
        log('backup_download','SQLite backup');db().commit()
        with tempfile.TemporaryDirectory() as temporary:
            target=Path(temporary)/'sawn.sqlite3'
            copy=sqlite3.connect(target)
            try:db().backup(copy)
            finally:copy.close()
            content=target.read_bytes()
        response=send_file(io.BytesIO(content),mimetype='application/vnd.sqlite3',as_attachment=True,download_name=f'sawn-backup-{today().isoformat()}.sqlite3')
        response.headers['Cache-Control']='no-store'
        return response

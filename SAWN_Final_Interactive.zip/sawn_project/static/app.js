(() => {
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const store = {
    get(key, session = false) { try { return (session ? sessionStorage : localStorage).getItem(key); } catch (_) { return null; } },
    set(key, value, session = false) { try { (session ? sessionStorage : localStorage).setItem(key, value); } catch (_) {} },
    remove(key, session = false) { try { (session ? sessionStorage : localStorage).removeItem(key); } catch (_) {} }
  };
  const extraAr = {
    introTagline:'صَوْن · عناية بأجهزتك، انسيابية في عملك', introLoading:'جارٍ تجهيز مساحة الصيانة…', skipIntro:'تخطّي المقدمة', skipContent:'انتقل إلى المحتوى', themeToggle:'تبديل المظهر', shortcuts:'اختصارات لوحة المفاتيح',
    searchShortcut:'فتح البحث', closePanels:'إغلاق النافذة المفتوحة', mySummary:'ملخص حسابي', slowDevice:'جهازي بطيء',
    botHelp:'كيف أستخدم الموقع؟', botSubtitle:'مساعد إرشادي محلي', botNote:'إرشادات محلية وبيانات حسابك؛ لا ينفذ تغييرات نيابةً عنك.',
    askAssistant:'اسأل مساعد صَوْن', registeredDevices:'الأجهزة المسجلة', openTickets:'البلاغات المفتوحة',
    completedTickets:'البلاغات المكتملة', myOpenTasks:'مهامي المتبقية', searching:'جارٍ البحث…', noResults:'لا توجد نتائج مطابقة',
    searchFailed:'تعذّر البحث. حاول مجددًا.', working:'جارٍ تنفيذ الطلب…', saving:'جارٍ الحفظ…',
    showPassword:'إظهار', hidePassword:'إخفاء', cleared:'تم مسح المحادثة', typing:'المساعد يحضّر الرد…',
    chatFailed:'تعذّر الحصول على الرد. تحقق من الاتصال ثم حاول مجددًا.', sessionExpired:'انتهت الجلسة. سجّل الدخول مجددًا.',
    filterMatches:'عدد النتائج', emptyFilter:'لا توجد سجلات تطابق بحثك', themeChanged:'تم تغيير المظهر', online:'متصل بالإنترنت',
    offline:'أنت غير متصل بالإنترنت. قد لا تُحفظ التغييرات حتى يعود الاتصال.',
    botGreeting:'أهلًا بك في صَوْن! اسألني عن خطوات النظام، ملخص حسابك، أو اكتب رقم الجهاز أو البلاغ لمتابعته.'
  };
  const extraEn = {
    introTagline:'Care for your devices. Flow for your work.', introLoading:'Preparing your maintenance workspace…', skipIntro:'Skip intro', skipContent:'Skip to content', themeToggle:'Switch appearance', shortcuts:'Keyboard shortcuts', searchShortcut:'Open search',
    closePanels:'Close the open panel', mySummary:'My summary', slowDevice:'My computer is slow', botHelp:'How does SAWN work?',
    botSubtitle:'Local workflow guide', botNote:'Local guidance and your account data; no changes are made on your behalf.',
    askAssistant:'Ask SAWN Assistant', registeredDevices:'Registered devices', openTickets:'Open tickets',
    completedTickets:'Completed tickets', myOpenTasks:'My remaining tasks', searching:'Searching…', noResults:'No matching results',
    searchFailed:'Search is unavailable. Please try again.', working:'Working on your request…', saving:'Saving…',
    showPassword:'Show', hidePassword:'Hide', cleared:'Conversation cleared', typing:'The assistant is preparing a reply…',
    chatFailed:'Unable to get a reply. Check your connection and try again.', sessionExpired:'Your session expired. Please sign in again.',
    filterMatches:'Matching records', emptyFilter:'No records match your search', themeChanged:'Appearance updated', online:'Back online',
    offline:'You are offline. Changes may not save until the connection returns.',
    botGreeting:'Welcome to SAWN! Ask about workflows or your account summary, or send an asset tag or ticket number to look it up.'
  };
  const dictionaries = { ar: {...window.sawnAr, ...extraAr}, en: {...window.sawnEn, ...extraEn} };
  let lang = store.get('sawnLang') === 'en' ? 'en' : 'ar';
  const t = key => dictionaries[lang][key] || key;
  const element = (tag, cls, text) => { const el = document.createElement(tag); if (cls) el.className = cls; if (text) el.textContent = text; return el; };
  function setLanguage(value) {
    lang = value; store.set('sawnLang', value);
    document.documentElement.lang = value;
    document.documentElement.dir = value === 'ar' ? 'rtl' : 'ltr';
    $$('[data-i18n]').forEach(el => { if (dictionaries[value][el.dataset.i18n]) el.textContent = t(el.dataset.i18n); });
    $$('[data-i18n-placeholder]').forEach(el => el.placeholder = t(el.dataset.i18nPlaceholder));
    $$('.multilang').forEach(el => el.textContent = el.dataset[value] || el.dataset.ar);
    if ($('#languageLabel')) $('#languageLabel').textContent = value === 'ar' ? 'English' : 'العربية';
    if ($('#todayDate')) $('#todayDate').textContent = new Intl.DateTimeFormat(value === 'ar' ? 'ar-AE' : 'en-GB', {weekday:'long', day:'numeric', month:'long'}).format(new Date());
    $$('[data-count]').forEach(el => el.textContent = new Intl.NumberFormat(lang).format(Number(el.dataset.count)));
    $$('.filterInput').forEach(el => el.dispatchEvent(new Event('input')));
    if ($('#passwordToggle')) $('#passwordToggle').textContent = t($('#loginPassword').type === 'password' ? 'showPassword' : 'hidePassword');
  }
  setLanguage(lang);
  $('#languageToggle')?.addEventListener('click', () => setLanguage(lang === 'ar' ? 'en' : 'ar'));
  // Branded entrance once per tab session, independent of remote fonts.
  const intro = $('#introScreen');
  const introPending = document.documentElement.classList.contains('introPending');
  const introBackground = introPending ? [...document.body.children].filter(el => el !== intro && el.tagName !== 'SCRIPT').map(el => ({el, inert:el.inert})) : [];
  if (introPending) introBackground.forEach(({el}) => el.inert = true);
  let introClosed = false;
  const closeIntro = () => {
    if (introClosed) return;
    introClosed = true;
    const returnFocus = intro?.contains(document.activeElement);
    document.documentElement.classList.remove('introPending');
    if (intro) intro.hidden = true;
    introBackground.forEach(({el,inert}) => el.inert = inert);
    store.set('sawnIntroSeen:brand-v2', '1', true);
    if (returnFocus) $('#mainContent')?.focus({preventScroll:true});
    document.dispatchEvent(new Event('sawn:intro-ready'));
  };
  if (!introPending) closeIntro();
  else {
    intro?.addEventListener('animationend', event => { if (event.target === intro && event.animationName === 'introExit') closeIntro(); });
    $('#skipIntro')?.addEventListener('click', closeIntro);
    document.addEventListener('keydown', event => { if (!introClosed && event.key === 'Escape') { event.preventDefault(); closeIntro(); } });
    setTimeout(closeIntro, 3100);
  }

  function toast(message) {
    const region = $('#toastRegion'); if (!region) return;
    const item = element('div', 'toast', message); region.append(item);
    while (region.children.length > 3) region.firstElementChild.remove();
    setTimeout(() => item.remove(), 5000);
  }
  let pendingRequests = 0;
  function progress(start) {
    pendingRequests = Math.max(0, pendingRequests + (start ? 1 : -1));
    $('#requestProgress').hidden = pendingRequests === 0;
    $('#requestStatus').textContent = pendingRequests ? t('working') : '';
  }
  let navigating = false;
  function navigationStart() { if (!navigating) { navigating = true; progress(true); } }
  document.addEventListener('click', event => {
    const a = event.target.closest('a[href]');
    if (!a || event.defaultPrevented || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || event.button !== 0 || a.target || a.hasAttribute('download')) return;
    const url = new URL(a.href, location.href);
    if (url.origin === location.origin && (url.pathname !== location.pathname || url.search !== location.search)) navigationStart();
  });
  $$('form:not(#chatForm)').forEach(form => form.addEventListener('submit', event => {
    if (event.defaultPrevented || !form.checkValidity()) return;
    if (form.dataset.submitting) { event.preventDefault(); return; }
    form.dataset.submitting = 'true';
    const button = event.submitter || form.querySelector('button:not([type=button])');
    if (button) { button.dataset.originalText = button.textContent; button.classList.add('isLoading'); button.setAttribute('aria-disabled', 'true'); button.setAttribute('aria-busy', 'true'); }
    form.setAttribute('aria-busy','true'); navigationStart();
    if (form.action.endsWith('/logout')) store.remove(`sawnChat:${document.body.dataset.user}`, true);
  }));
  window.addEventListener('pageshow', () => {
    pendingRequests = 0; navigating = false; $('#requestProgress').hidden = true;
    $$('form[data-submitting]').forEach(f => { delete f.dataset.submitting; f.removeAttribute('aria-busy'); });
    $$('.isLoading').forEach(b => { b.classList.remove('isLoading'); b.removeAttribute('aria-disabled'); b.removeAttribute('aria-busy'); });
  });
  window.addEventListener('offline', () => toast(t('offline')));
  window.addEventListener('online', () => toast(t('online')));

  // Drawer focus, keyboard access and active page state.
  const drawer = $('#drawer'), scrim = $('#scrim');
  let previousDrawerFocus;
  function toggleDrawer(open) {
    if (!drawer) return;
    if (open) previousDrawerFocus = document.activeElement;
    drawer.inert = !open; drawer.classList.toggle('open',open); scrim.classList.toggle('open',open);
    $('#menuToggle').setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('drawerVisible',open);
    if (open) requestAnimationFrame(() => { if (drawer.classList.contains('open')) $('#closeDrawer').focus(); }); else previousDrawerFocus?.focus();
  }
  $('#menuToggle')?.addEventListener('click', () => toggleDrawer(true));
  $('#closeDrawer')?.addEventListener('click', () => toggleDrawer(false));
  scrim?.addEventListener('click', () => toggleDrawer(false));
  drawer?.addEventListener('keydown', event => {
    if (event.key !== 'Tab') return;
    const nodes = [...drawer.querySelectorAll('a,button,input')].filter(el => !el.disabled && el.getClientRects().length);
    const first = nodes[0], last = nodes[nodes.length-1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  $$('.drawer nav a').forEach(a => { if (new URL(a.href).pathname === location.pathname || (new URL(a.href).pathname !== '/' && location.pathname.startsWith(new URL(a.href).pathname + '/'))) { a.classList.add('active'); a.setAttribute('aria-current','page'); } });
  $('#themeToggle')?.setAttribute('aria-pressed', String(document.documentElement.dataset.theme === 'dark'));
  $('#themeToggle')?.addEventListener('click', () => {
    const dark = document.documentElement.dataset.theme !== 'dark';
    document.documentElement.dataset.theme = dark ? 'dark' : 'light'; store.set('sawnTheme', dark ? 'dark' : 'light');
    $('#themeToggle').setAttribute('aria-pressed', String(dark)); toast(t('themeChanged'));
  });
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const slider = $('#sectionSlider');
  const moveSlider = step => slider?.scrollBy({left:step * (lang === 'ar' ? -210 : 210), behavior:reduced ? 'auto' : 'smooth'});
  $('#sliderNext')?.addEventListener('click', () => moveSlider(1));
  $('#sliderPrev')?.addEventListener('click', () => moveSlider(-1));
  function showModal(id) {
    if (!introClosed) return;
    const dialog = document.getElementById(id);
    if (dialog instanceof HTMLDialogElement && !dialog.open) dialog.showModal();
  }
  $$('[data-modal]').forEach(b => b.addEventListener('click', () => showModal(b.dataset.modal)));
  $$('[data-close]').forEach(b => b.addEventListener('click', () => b.closest('dialog')?.close()));
  $$('dialog').forEach(d => {
    const heading = d.querySelector('h2');
    if (heading && !d.hasAttribute('aria-labelledby')) { heading.id ||= `${d.id}Title`; d.setAttribute('aria-labelledby', heading.id); }
    d.addEventListener('click', event => { const r = d.getBoundingClientRect(); if (event.target === d && (event.clientX<r.left || event.clientX>r.right || event.clientY<r.top || event.clientY>r.bottom)) d.close(); });
  });
  const hashModal = () => { try { const id = decodeURIComponent(location.hash.slice(1)); if (document.getElementById(id) instanceof HTMLDialogElement) { showModal(id); window.history.replaceState(null,'',location.pathname+location.search); } } catch (_) {} };
  if (introClosed) hashModal(); else document.addEventListener('sawn:intro-ready', hashModal, {once:true});
  window.addEventListener('hashchange', () => { if (introClosed) hashModal(); });
  $$('.dismissFlash').forEach(b => b.addEventListener('click', () => b.closest('.flash').remove()));
  $('#passwordToggle')?.addEventListener('click', () => {
    const input = $('#loginPassword'), showing = input.type === 'password'; input.type = showing ? 'text' : 'password';
    $('#passwordToggle').setAttribute('aria-pressed', String(showing)); $('#passwordToggle').textContent = t(showing ? 'hidePassword' : 'showPassword');
  });
  $$('.filterInput').forEach(input => {
    const feedback = element('p','filterFeedback'); feedback.setAttribute('role','status'); input.after(feedback);
    input.setAttribute('aria-label', input.placeholder);
    input.addEventListener('input', () => {
      const query = input.value.trim().toLocaleLowerCase(); let count = 0;
      $$(input.dataset.filter).forEach(row => { row.hidden = !row.textContent.toLocaleLowerCase().includes(query); if (!row.hidden && !row.querySelector('[colspan]')) count++; });
      feedback.textContent = query ? (count ? `${t('filterMatches')}: ${count}` : t('emptyFilter')) : '';
    });
  });

  // Live search: cancel obsolete requests and allow keyboard selection.
  const search = $('#globalSearch'), results = $('#searchResults');
  let searchTimer, searchController, searchSequence = 0, selected = -1;
  function closeSearch() { if (results) { results.hidden = true; search.setAttribute('aria-expanded','false'); } }
  function searchMessage(key) { results.replaceChildren(element('p','searchMessage',t(key))); results.hidden = false; search.setAttribute('aria-expanded','true'); }
  search?.addEventListener('input', () => {
    clearTimeout(searchTimer); searchController?.abort(); const sequence = ++searchSequence;
    const query = search.value.trim(); selected = -1; results.replaceChildren(); closeSearch();
    if (query.length < 2) return;
    searchTimer = setTimeout(async () => {
      searchController = new AbortController(); const controller = searchController;
      searchMessage('searching'); results.setAttribute('aria-busy','true'); progress(true);
      const timeout = setTimeout(() => controller.abort(), 10000);
      try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`, {signal:controller.signal});
        if (response.redirected) { searchMessage('sessionExpired'); return; }
        if (!response.ok) throw new Error('Search failed');
        const data = await response.json(); if (sequence !== searchSequence) return;
        results.replaceChildren();
        data.forEach(item => { if (typeof item.url !== 'string' || !item.url.startsWith('/') || item.url.startsWith('//')) return; const a = element('a','searchResult',item.title); a.href = item.url; results.append(a); });
        if (!results.children.length) searchMessage('noResults'); else { results.hidden = false; search.setAttribute('aria-expanded','true'); }
      } catch (_) { if (sequence === searchSequence) searchMessage('searchFailed'); }
      finally { clearTimeout(timeout); if (sequence === searchSequence) results.removeAttribute('aria-busy'); progress(false); }
    }, 250);
  });
  search?.addEventListener('keydown', e => {
    const links = [...results.querySelectorAll('a')];
    if (e.key === 'Escape') { closeSearch(); search.blur(); }
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && links.length && !results.hidden) {
      e.preventDefault(); selected = (selected + (e.key === 'ArrowDown' ? 1 : -1) + links.length) % links.length;
      links.forEach((a,i) => a.classList.toggle('selected', i === selected)); links[selected].scrollIntoView({block:'nearest'});
    }
    if (e.key === 'Enter' && links.length && !results.hidden) { e.preventDefault(); links[Math.max(0,selected)].click(); }
  });
  document.addEventListener('click', e => { if (!e.target.closest('.searchBox')) closeSearch(); });

  // Read-only assistant, backed by the actual signed-in account.
  const chat = $('#chatPanel'), area = $('#chatMessages');
  const chatKey = `sawnChat:${document.body.dataset.user}`;
  let chatBusy = false, chatController, chatVersion = 0, history = [];
  try { const saved = JSON.parse(store.get(chatKey,true) || '[]'); if (Array.isArray(saved)) history = saved.filter(m => ['user','bot'].includes(m.role) && typeof m.text === 'string').slice(-24); } catch (_) {}
  function bubble(role, text, links = []) {
    const node = element('div', role === 'user' ? 'userBubble' : 'botBubble');
    node.append(element('p','bubbleText',text));
    if (role === 'bot' && Array.isArray(links)) {
      const actions = element('div','botActions');
      links.slice(0,3).forEach(link => {
        if (typeof link.url !== 'string' || !link.url.startsWith('/') || link.url.startsWith('//') || typeof link.label !== 'string') return;
        const a = element('a','botAction',link.label); a.href = link.url; actions.append(a);
      });
      if (actions.children.length) node.append(actions);
    }
    area?.append(node);
    while (area?.children.length > 30) area.firstElementChild.remove();
    if (area) area.scrollTop = area.scrollHeight;
    return node;
  }
  function greet() { const n = bubble('bot',t('botGreeting')); n.querySelector('p').dataset.i18n = 'botGreeting'; }
  if (area) { greet(); history.forEach(m => bubble(m.role,m.text,m.links)); }
  function saveChat(role, text, links = []) { history.push({role,text,links}); history = history.slice(-24); store.set(chatKey,JSON.stringify(history),true); }
  function openChat(open = true) { if (!chat) return; chat.hidden = !open; $('#botToggle').setAttribute('aria-expanded', String(open)); if (open) { $('#chatInput').focus(); area.scrollTop = area.scrollHeight; } else $('#botToggle').focus(); }
  $('#botToggle')?.addEventListener('click', () => openChat(chat.hidden));
  $('#askAssistant')?.addEventListener('click', () => openChat());
  $('#botClose')?.addEventListener('click', () => openChat(false));
  function setChatBusy(busy) { chatBusy = busy; $('#chatSend').disabled = busy; $$('.quickQuestions button').forEach(b => b.disabled = busy); }
  async function sendChat(text, intent) {
    text = text.trim().slice(0,600); if (!text || chatBusy) return;
    bubble('user',text); saveChat('user',text); $('#chatInput').value = ''; setChatBusy(true);
    const version = chatVersion;
    const thinking = element('div','botBubble typingBubble'); thinking.setAttribute('role','status'); thinking.setAttribute('aria-label',t('typing'));
    const dots = element('span','typingDots'); dots.setAttribute('aria-hidden','true'); dots.append(element('i'),element('i'),element('i')); thinking.append(dots); area.append(thinking); area.scrollTop = area.scrollHeight;
    chatController = new AbortController(); const controller = chatController;
    const timeout = setTimeout(() => controller.abort(),12000); progress(true);
    try {
      const response = await fetch('/api/assistant', {
        method:'POST', credentials:'same-origin', signal:controller.signal,
        headers:{'Content-Type':'application/json','X-CSRF-Token':document.body.dataset.csrf},
        body:JSON.stringify({message:text,language:lang,intent})
      });
      if (version !== chatVersion) return;
      if (response.redirected || response.status === 401) throw new Error('expired');
      if (!response.ok) throw new Error('failed');
      const data = await response.json(); if (version !== chatVersion) return; if (typeof data.reply !== 'string') throw new Error('failed');
      thinking.remove(); bubble('bot',data.reply,data.links); saveChat('bot',data.reply,data.links);
    } catch (error) {
      if (version === chatVersion) { thinking.remove(); bubble('bot',t(error.message === 'expired' ? 'sessionExpired' : 'chatFailed')); }
    } finally { clearTimeout(timeout); thinking.remove(); progress(false); if (version === chatVersion) setChatBusy(false); }
  }
  $('#chatForm')?.addEventListener('submit', e => { e.preventDefault(); sendChat($('#chatInput').value); });
  $$('[data-question]').forEach(b => b.addEventListener('click', () => sendChat(b.textContent,b.dataset.question)));
  $('#chatReset')?.addEventListener('click', () => { chatVersion++; chatController?.abort(); history = []; store.remove(chatKey,true); area.replaceChildren(); greet(); setChatBusy(false); toast(t('cleared')); $('#chatInput').focus(); });

  document.addEventListener('keydown', event => {
    const editing = event.target.closest('input,textarea,select,[contenteditable=true]');
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k' && search && !$('dialog[open]')) {
      event.preventDefault(); if (drawer?.classList.contains('open')) toggleDrawer(false); search.focus(); search.select();
    }
    if (event.key === '?' && !editing && $('#shortcutsDialog') && !$('dialog[open]')) { event.preventDefault(); showModal('shortcutsDialog'); }
    if (event.key === 'Escape' && !$('dialog[open]')) { if (drawer?.classList.contains('open')) toggleDrawer(false); else if (chat && !chat.hidden) openChat(false); closeSearch(); }
  });
  const topButton = $('#backToTop');
  window.addEventListener('scroll', () => { if (topButton) topButton.hidden = scrollY < 420; }, {passive:true});
  topButton?.addEventListener('click', () => window.scrollTo({top:0,behavior:reduced ? 'auto' : 'smooth'}));
  // Scroll reveals and real-data counters; content stays available without JS.
  if (!reduced && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('revealed'); observer.unobserve(entry.target);
    }), {threshold:0.08});
    $$('.sectionTop,.slide,.serviceCard,.panel,.overview,.pageTitle,.emptyBig').forEach((el,i) => { el.classList.add('reveal'); el.style.setProperty('--reveal-delay',`${Math.min(i%6,4)*45}ms`); observer.observe(el); });
    const counts = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const node = entry.target, value = Number(node.dataset.count); let start;
      function frame(now) { start ??= now; const fraction = Math.min((now-start)/650,1); node.textContent = new Intl.NumberFormat(lang).format(Math.round(value*(1-(1-fraction)**3))); if (fraction<1) requestAnimationFrame(frame); }
      requestAnimationFrame(frame); counts.unobserve(node);
    }));
    $$('[data-count]').forEach(el => counts.observe(el));
  }
})();

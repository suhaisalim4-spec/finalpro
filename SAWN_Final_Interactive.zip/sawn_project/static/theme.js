/* Apply the saved theme before the first paint; storage may be disabled. */
try {
  const theme = localStorage.getItem('sawnTheme');
  document.documentElement.dataset.theme = theme === 'dark' || theme === 'light'
    ? theme : (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
} catch (_) { document.documentElement.dataset.theme = 'light'; }
try { if (!sessionStorage.getItem('sawnIntroSeen:brand-v2') && !matchMedia('(prefers-reduced-motion: reduce)').matches) document.documentElement.classList.add('introPending'); } catch (_) {}

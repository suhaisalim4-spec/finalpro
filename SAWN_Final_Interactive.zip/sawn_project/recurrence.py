"""Record completed maintenance and maintain one next appointment per device/action."""
import json
from datetime import date,timedelta
from domain import today

ACTIONS={
 'cleaning':'تنظيف الجهاز والمراوح',
 'thermal_paste':'تغيير المعجون الحراري',
 'parts_replacement':'استبدال قطعة وفحص الجهاز',
 'cooling':'صيانة نظام التبريد',
 'disk_check':'فحص القرص والتخزين',
 'general':'صيانة وفحص عام',
}
LEGACY={
 'فحص المعجون الحراري':'thermal_paste','تغيير المعجون الحراري':'thermal_paste',
 'تنظيف الجهاز والمراوح':'cleaning','فحص القرص الصلب':'disk_check',
 'فحص نظام التبريد':'cooling',**{v:k for k,v in ACTIONS.items()},
}


def parse_actions(values):
    values=list(dict.fromkeys(values)) or ['general']
    if any(value not in ACTIONS for value in values):raise ValueError('اختر نوع صيانة صحيحًا')
    return values


def performed_date(value):
    try:day=date.fromisoformat(value) if value else today()
    except (TypeError,ValueError):raise ValueError('تاريخ تنفيذ الصيانة غير صحيح') from None
    if day>today():raise ValueError('لا يمكن تسجيل صيانة مكتملة بتاريخ مستقبلي')
    return day


def record_service(conn,device_id,actions,performed_on,performed_by,details='',ticket_id=None,event_id=None):
    day=performed_date(performed_on)
    due=(day+timedelta(days=90)).isoformat()
    for code in parse_actions(actions):
        key=f"{device_id}:{code}:{day.isoformat()}:{event_id or 'manual'}"
        existing=conn.execute('SELECT id FROM maintenance_records WHERE service_key=?',(key,)).fetchone()
        if existing:continue
        schedules=conn.execute('SELECT * FROM schedules WHERE device_id=? AND service_code=? ORDER BY last_done DESC,is_active DESC,id',(device_id,code)).fetchall()
        if schedules:
            schedule_id=schedules[0]['id']
            # Old duplicate rows are preserved as inactive history; only one next date is active.
            conn.execute('UPDATE schedules SET is_active=0 WHERE device_id=? AND service_code=? AND id!=?',(device_id,code,schedule_id))
            conn.execute('UPDATE schedules SET is_active=1 WHERE id=?',(schedule_id,))
            # Recording an older job must not replace a more recent next appointment.
            if not schedules[0]['last_done'] or day.isoformat()>=schedules[0]['last_done']:
                conn.execute('UPDATE schedules SET kind=?,due_date=?,interval_days=90,assigned_to=?,last_done=?,is_active=1 WHERE id=?',(ACTIONS[code],due,performed_by,day.isoformat(),schedule_id))
        else:
            cursor=conn.execute('INSERT INTO schedules(device_id,kind,due_date,interval_days,assigned_to,last_done,service_code,is_active) VALUES (?,?,?,90,?,?,?,1)',(device_id,ACTIONS[code],due,performed_by,day.isoformat(),code))
            schedule_id=cursor.lastrowid
        conn.execute('INSERT INTO maintenance_records(device_id,ticket_id,event_id,schedule_id,service_code,performed_on,performed_by,details,next_due,service_key) VALUES (?,?,?,?,?,?,?,?,?,?)',
                     (device_id,ticket_id,event_id,schedule_id,code,day.isoformat(),performed_by,details,due,key))
    return due

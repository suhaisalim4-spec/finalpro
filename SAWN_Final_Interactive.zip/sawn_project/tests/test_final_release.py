"""Final release behavior: automatic care, simple Arabic reports, and real PDFs."""
import importlib
import json
import os
import sqlite3
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch
from werkzeug.datastructures import MultiDict


class FinalReleaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        with patch.dict(os.environ,{'SAWN_DB':str(Path(cls.temp.name)/'initial.db')}):
            cls.module=importlib.import_module('app')
        cls.app=cls.module.app;cls.app.config['TESTING']=True

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def setUp(self):
        self.module.DB=Path(self.temp.name)/(self._testMethodName+'.db');self.module.setup()
        self.client=self.app.test_client()
        with self.app.app_context():
            con=self.module.db()
            con.execute("INSERT INTO devices(asset_tag,name) VALUES ('FINAL-001','حاسوب مكتب الصيانة')")
            con.execute("INSERT INTO tickets(device_id,issue,status,assigned_to,created_by) VALUES (1,'ارتفاع الحرارة وبطء التشغيل','جديد',2,3)")
            con.commit()
        self.day=self.module.today();self.due=(self.day+timedelta(days=90)).isoformat()

    def login(self,name='tech',password='Tech@2026'):
        self.assertEqual(self.client.post('/login',data={'username':name,'password':password}).status_code,302)
        with self.client.session_transaction() as state:return {'X-CSRF-Token':state['csrf']}

    def finish(self,headers,actions=('cleaning','thermal_paste','parts_replacement'),day=None):
        values=MultiDict({'status':'مكتمل','resolution':'تنظيف المراوح وتغيير المعجون واستبدال المروحة مع فحص الحرارة','performed_on':day or self.day.isoformat()})
        for action in actions:values.add('maintenance_actions',action)
        return self.client.post('/tickets/1/status',data=values,headers=headers)

    def test_completion_schedules_each_actual_action_after_ninety_days_once(self):
        headers=self.login();self.assertEqual(self.finish(headers).status_code,302)
        self.finish(headers)
        self.client.post('/tickets/1/notes',data={'note':'تم تسليم الجهاز بعد الفحص'},headers=headers)
        with self.app.app_context():
            con=self.module.db();rows=con.execute('SELECT * FROM schedules WHERE is_active=1').fetchall()
            self.assertEqual(len(rows),3)
            self.assertEqual({r['service_code'] for r in rows},{'cleaning','thermal_paste','parts_replacement'})
            self.assertTrue(all((r['due_date'],r['interval_days'],r['last_done'],r['assigned_to'])==(self.due,90,self.day.isoformat(),2) for r in rows))
            self.assertEqual(con.execute('SELECT count(*) FROM maintenance_records').fetchone()[0],3)
            self.assertEqual(con.execute("SELECT count(*) FROM ticket_events WHERE new_status='مكتمل'").fetchone()[0],1)
            self.assertEqual(json.loads(con.execute('SELECT maintenance_actions FROM tickets').fetchone()[0]),['cleaning','thermal_paste','parts_replacement'])

    def test_backdated_completion_uses_actual_date_and_old_jobs_cannot_move_new_appointment_back(self):
        headers=self.login();older=self.day-timedelta(days=12)
        self.finish(headers,actions=('cleaning',),day=older.isoformat())
        with self.app.app_context():
            con=self.module.db();row=con.execute('SELECT * FROM schedules').fetchone()
            self.assertEqual(row['due_date'],(older+timedelta(days=90)).isoformat())
            self.assertEqual(con.execute('SELECT completed_at FROM tickets').fetchone()[0],older.isoformat())
        for day in [self.day,self.day-timedelta(days=30)]:
            self.client.post('/maintenance',data={'device_id':1,'maintenance_actions':'cleaning','performed_on':day.isoformat()},headers=headers)
        with self.app.app_context():
            con=self.module.db();row=con.execute('SELECT * FROM schedules WHERE is_active=1').fetchone()
            self.assertEqual((row['last_done'],row['due_date']),(self.day.isoformat(),self.due))
            self.assertEqual(con.execute('SELECT count(*) FROM maintenance_records').fetchone()[0],3)

    def test_invalid_actual_dates_and_actions_do_not_complete_or_schedule(self):
        headers=self.login()
        for day,actions in [('invalid',('cleaning',)),((self.day+timedelta(days=1)).isoformat(),('cleaning',)),(self.day.isoformat(),('invented',))]:
            self.assertEqual(self.finish(headers,actions,day).status_code,302)
        with self.app.app_context():
            con=self.module.db();self.assertEqual(con.execute('SELECT status FROM tickets').fetchone()[0],'جديد')
            self.assertEqual(con.execute('SELECT count(*) FROM schedules').fetchone()[0],0)
            self.assertEqual(con.execute('SELECT count(*) FROM maintenance_records').fetchone()[0],0)

    def test_standalone_job_and_done_button_reuse_appointment_and_ignore_old_interval(self):
        headers=self.login()
        with self.app.app_context():
            con=self.module.db()
            con.execute("INSERT INTO schedules(device_id,kind,service_code,due_date,interval_days,assigned_to) VALUES (1,'تنظيف الجهاز والمراوح','cleaning',?,30,2)",(self.day.isoformat(),))
            con.commit()
        for _ in range(2):self.assertEqual(self.client.post('/maintenance/1/done',headers=headers).status_code,302)
        with self.app.app_context():
            con=self.module.db();self.assertEqual(tuple(con.execute('SELECT due_date,interval_days FROM schedules').fetchone()),(self.due,90))
            self.assertEqual(con.execute('SELECT count(*) FROM maintenance_records').fetchone()[0],1)
        for _ in range(2):
            self.client.post('/maintenance',data={'device_id':1,'maintenance_actions':'thermal_paste','performed_on':self.day.isoformat()},headers=headers)
        with self.app.app_context():
            con=self.module.db();self.assertEqual(con.execute('SELECT count(*) FROM schedules WHERE is_active=1').fetchone()[0],2)
            self.assertEqual(con.execute('SELECT count(*) FROM maintenance_records').fetchone()[0],2)
        page=self.client.get('/maintenance').get_data(as_text=True)
        self.assertNotIn('name="due_date"',page);self.assertNotIn('name="interval_days"',page)
        self.assertIn('٩٠',page)

    def test_legacy_unknown_schedule_can_be_completed_and_duplicate_dates_stay_inactive(self):
        headers=self.login('admin','Sawn@2026')
        with self.app.app_context():
            con=self.module.db()
            con.execute("INSERT INTO schedules(device_id,kind,due_date,interval_days,assigned_to) VALUES (1,'فحص مخصص قديم',?,10,2)",(self.day.isoformat(),))
            con.commit()
        self.assertEqual(self.client.post('/maintenance/1/done',headers=headers).status_code,302)
        with self.app.app_context():
            con=self.module.db();self.assertEqual(tuple(con.execute('SELECT due_date,interval_days,is_active FROM schedules WHERE id=1').fetchone()),(self.due,90,1))
            con.execute("INSERT INTO schedules(device_id,kind,service_code,due_date,assigned_to) VALUES (1,'صيانة وفحص عام','general',?,2)",(self.day.isoformat(),));con.commit()
        self.client.post('/maintenance',data={'device_id':1,'assigned_to':2,'performed_on':(self.day-timedelta(days=5)).isoformat()},headers=headers)
        with self.app.app_context():
            con=self.module.db();self.assertEqual(con.execute('SELECT count(*) FROM schedules').fetchone()[0],2)
            self.assertEqual(con.execute('SELECT count(*) FROM schedules WHERE is_active=1').fetchone()[0],1)
            self.assertEqual(con.execute('SELECT due_date FROM schedules WHERE is_active=1').fetchone()[0],self.due)

    def test_employee_cannot_record_work_and_admin_must_choose_active_technician(self):
        headers=self.login('employee','Employee@2026')
        self.assertEqual(self.client.post('/maintenance',data={'device_id':1},headers=headers).status_code,403)
        headers=self.login('admin','Sawn@2026')
        for assignee in [None,3,999]:
            self.client.post('/maintenance',data={'device_id':1,'assigned_to':assignee,'performed_on':self.day.isoformat()},headers=headers)
        with self.app.app_context():self.assertEqual(self.module.db().execute('SELECT count(*) FROM maintenance_records').fetchone()[0],0)

    def test_maintenance_log_cannot_bypass_ticket_privacy(self):
        from werkzeug.security import generate_password_hash
        with self.app.app_context():
            con=self.module.db()
            con.execute('UPDATE tickets SET created_by=1')
            con.execute("INSERT INTO users(username,password_hash,display_name,role) VALUES ('othertech',?,'فني آخر','technician')",(generate_password_hash('OtherTech@2026'),))
            con.commit()
        headers=self.login();self.finish(headers,actions=('cleaning',))
        detail='تنظيف المراوح وتغيير المعجون واستبدال المروحة مع فحص الحرارة'
        self.assertIn(detail,self.client.get('/maintenance').get_data(as_text=True))
        for user,password in [('employee','Employee@2026'),('othertech','OtherTech@2026')]:
            self.login(user,password)
            self.assertNotIn(detail,self.client.get('/maintenance').get_data(as_text=True))
        self.login('admin','Sawn@2026')
        self.assertIn(detail,self.client.get('/maintenance').get_data(as_text=True))

    def test_report_has_one_clear_record_and_download_is_pdf_with_saved_content(self):
        headers=self.login();self.finish(headers)
        self.login('admin','Sawn@2026');start=self.day.isoformat()
        page=self.client.get('/reports?start='+start).get_data(as_text=True)
        for label in ['اسم الجهاز','العطل المسجّل','الفني المسؤول','ما العمل الذي أُنجز؟','تاريخ إكمال الإصلاح','الصيانة القادمة']:
            self.assertIn(label,page)
        from automation import report_data
        from reporting import present_report
        with self.app.app_context():payload=report_data(self.module.db(),self.day)
        self.assertEqual(len(present_report(payload)['records']),1)
        pdf=self.client.get('/reports/export?start='+start)
        self.assertEqual(pdf.mimetype,'application/pdf');self.assertTrue(pdf.data.startswith(b'%PDF-'))
        self.assertIn('.pdf',pdf.headers['Content-Disposition']);self.assertNotIn('CSV',page)
        with self.app.app_context():
            con=self.module.db();con.execute('INSERT INTO weekly_reports(week_start,week_end,generated_at,payload) VALUES (?,?,?,?)',(start,payload['end'],start,json.dumps(payload)));con.execute("UPDATE tickets SET issue='عدّل بعد الحفظ'");con.commit()
        saved=self.client.get('/reports/archive/1').get_data(as_text=True)
        self.assertIn('ارتفاع الحرارة',saved);self.assertNotIn('عدّل بعد الحفظ',saved)
        self.assertTrue(self.client.get('/reports/export?id=1').data.startswith(b'%PDF-'))

    def test_long_arabic_pdf_can_paginate_and_old_snapshots_remain_readable(self):
        from reporting import render_report_pdf,present_report
        old={'start':'2026-10-19','end':'2026-10-25','repairs':[{'id':12,'asset_tag':'OLD-12','issue':'فحص الجهاز '*250,'status':'مكتمل','resolution':'تم تنظيف الجهاز وفحص الحرارة. '*100}],'completed':[]}
        view=present_report(old);self.assertEqual(view['records'][0]['device'],'غير مسجّل')
        document=render_report_pdf(old);self.assertTrue(document.startswith(b'%PDF-'));self.assertGreater(document.count(b'/Type /Page\n'),1)

    def test_pdf_embeds_glyphs_for_latin_asset_tags_and_arabic_dates(self):
        from reporting import report_fonts,visual_runs,date_label
        from reportlab.pdfbase import pdfmetrics
        regular,_=report_fonts()
        runs=visual_runs('الجهاز FINAL-001 / 2026 — تم الإصلاح',regular)
        for name,value in runs:
            charset=pdfmetrics.getFont(name).face.charToGlyph
            self.assertTrue(all(ord(character) in charset for character in value),(name,value))
        self.assertEqual(date_label('2026-10-26'),'26 أكتوبر 2026')

    def test_arabic_only_interface_even_with_previous_english_preference(self):
        from html.parser import HTMLParser
        import re
        class Text(HTMLParser):
            def __init__(self):super().__init__();self.parts=[]
            def handle_data(self,value):self.parts.append(value)
        headers=self.login('admin','Sawn@2026')
        self.client.post('/preferences',data={'language':'en','theme':'dark'},headers=headers)
        for path in ['/','/devices','/tickets','/tickets/1','/maintenance','/reports','/news','/team','/users','/assistant','/admin','/support']:
            page=self.client.get(path).get_data(as_text=True);parser=Text();parser.feed(page)
            # Usernames and the device asset tag are identifiers, not interface translations.
            words=set(re.findall(r'[A-Za-z][A-Za-z_-]*',' '.join(parser.parts)))
            self.assertTrue(words<={'admin','tech','employee','FINAL-'},(path,words))
            self.assertIn('lang="ar"',page);self.assertIn('dir="rtl"',page)
            self.assertNotIn('name="language"',page)
        reply=self.client.post('/api/assistant',json={'message':'my summary','language':'en'},headers=headers).get_json()
        self.assertIn('الأجهزة المسجلة',reply['reply']);self.assertNotIn('Registered devices',reply['reply'])

    def test_upgrade_from_previous_version_preserves_records_and_saves_pre_upgrade_copy(self):
        from automation import backup_directory
        database=Path(self.temp.name)/'previous-final.db'
        con=sqlite3.connect(database)
        schema=(Path(self.module.__file__).parent/'schema.sql').read_text().split('CREATE TABLE IF NOT EXISTS maintenance_records(')[0]
        con.executescript(schema)
        con.execute("INSERT INTO devices(asset_tag,name) VALUES ('KEEP-1','جهاز محفوظ')")
        con.execute("INSERT INTO schedules(device_id,kind,due_date,interval_days) VALUES (1,'فحص المعجون الحراري','2026-12-01',45)")
        con.commit();con.close()
        self.module.DB=database;self.module.setup()
        copies=list(backup_directory(database).glob('sawn-before-upgrade-final-*.sqlite3'));self.assertEqual(len(copies),1)
        with self.app.app_context():
            con=self.module.db();self.assertEqual(con.execute('SELECT name FROM devices').fetchone()[0],'جهاز محفوظ')
            row=con.execute('SELECT * FROM schedules').fetchone();self.assertEqual((row['due_date'],row['interval_days'],row['service_code']),('2026-12-01',45,'thermal_paste'))
        old=sqlite3.connect(copies[0]);self.assertEqual(old.execute('SELECT name FROM devices').fetchone()[0],'جهاز محفوظ');old.close()


if __name__=='__main__':unittest.main()

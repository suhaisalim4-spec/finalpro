"""Run with: python -m unittest discover -s tests -v"""
import importlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        with patch.dict(os.environ, {'SAWN_DB': str(Path(cls.temp.name) / 'initial.db')}):
            cls.module = importlib.import_module('app')
        cls.app = cls.module.app
        cls.app.config.update(TESTING=True)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        self.module.DB = Path(self.temp.name) / f'{self._testMethodName}.db'
        self.module.setup()
        self.client = self.app.test_client()
        with self.app.app_context():
            con = self.module.db()
            con.execute("INSERT INTO devices(asset_tag,name) VALUES ('PC-001','Test workstation')")
            con.execute("INSERT INTO tickets(device_id,issue,status) VALUES (1,'Disk issue','قيد الصيانة')")
            con.execute("INSERT INTO tasks(title,assigned_to,assigned_by) VALUES ('Private tech task',2,1)")
            con.execute("INSERT INTO tasks(title,assigned_to,assigned_by) VALUES ('Employee task',3,1)")
            con.commit()

    def login(self, name='admin', password='Sawn@2026'):
        response = self.client.post('/login', data={'username':name,'password':password})
        self.assertEqual(response.status_code,302)
        with self.client.session_transaction() as session:
            return {'X-CSRF-Token':session['csrf']}

    def ask(self, message, headers, **kwargs):
        return self.client.post('/api/assistant', json={'message':message,**kwargs}, headers=headers)

    def test_authentication_and_csrf_are_required(self):
        self.assertEqual(self.ask('help',{}).status_code,401)
        self.assertEqual(self.client.get('/').status_code,302)
        headers = self.login()
        self.assertEqual(self.ask('help',{}).status_code,400)
        self.assertEqual(self.ask('help',headers).status_code,200)
        self.client.get('/logout')  # GET must not log the user out.
        with self.client.session_transaction() as session:
            csrf = session['csrf']
        self.client.post('/logout',data={'_csrf':csrf})
        self.assertEqual(self.ask('help',headers).status_code,401)

    def test_summary_only_counts_the_current_users_tasks(self):
        headers = self.login('employee','Employee@2026')
        payload = self.ask('my summary',headers,language='en').get_json()
        self.assertIn('Registered devices: 1',payload['reply'])
        self.assertIn('Your remaining assigned tasks: 1',payload['reply'])
        self.assertNotIn('Private tech task',payload['reply'])
        self.assertNotIn('/admin',[x['url'] for x in payload['links']])
        self.assertEqual(self.client.get('/admin').status_code,403)

    def test_device_and_ticket_lookup(self):
        headers = self.login()
        device = self.ask('device PC-001',headers).get_json()
        self.assertIn('Test workstation',device['reply'])
        self.assertEqual(device['links'][0]['url'],'/devices/1')
        ticket = self.ask('بلاغ 1',headers).get_json()
        self.assertIn('قيد الصيانة',ticket['reply'])
        self.assertIn('Disk issue',ticket['reply'])
        self.assertIn('لم أجد', self.ask('بلاغ 999',headers).get_json()['reply'])

    def test_guides_and_role_specific_links(self):
        headers = self.login()
        self.assertTrue(any(x['url']=='/admin' for x in self.ask('task',headers).get_json()['links']))
        for message, endpoint in [('جهازي بطيء','/tickets#newTicket'),('الصيانة الدورية','/maintenance'),('تقرير','/reports'),('دعم','/support')]:
            reply = self.ask(message,headers).get_json()
            self.assertIn(endpoint,[x['url'] for x in reply['links']])

    def test_invalid_payloads_and_read_only_behavior(self):
        headers = self.login()
        for body in [[], {'message': []},{'message':''},{'message':'x'*601}]:
            self.assertEqual(self.client.post('/api/assistant',json=body,headers=headers).status_code,400)
        self.assertEqual(self.client.post('/api/assistant',data='not json',headers=headers).status_code,400)
        self.assertEqual(self.ask("'; DROP TABLE users; --",headers).status_code,200)
        self.assertEqual(self.ask('ticket '+('9'*500),headers).status_code,200)
        with self.app.app_context():
            self.assertEqual(self.module.db().execute('SELECT count(*) FROM users').fetchone()[0],3)
            self.assertEqual(self.module.db().execute('SELECT count(*) FROM tickets').fetchone()[0],1)

    def test_all_pages_and_original_create_workflow(self):
        headers = self.login()
        for route in ['/','/devices','/devices/1','/tickets','/technicians','/tasks','/maintenance','/news','/notifications','/reports','/support','/admin']:
            self.assertEqual(self.client.get(route).status_code,200,route)
        home = self.client.get('/').get_data(as_text=True)
        self.assertIn('newsStrip',home)
        self.assertIn('data-count="1"',home)
        self.assertNotIn('bottomGrid',home)
        response = self.client.post('/devices',data={'asset_tag':'PC-002','name':'New computer'},headers=headers,follow_redirects=True)
        self.assertEqual(response.status_code,200)
        self.assertIn('New computer',response.get_data(as_text=True))


if __name__ == '__main__':
    unittest.main()

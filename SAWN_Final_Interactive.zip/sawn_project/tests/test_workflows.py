"""Run with: python -m unittest discover -s tests -v"""
import importlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        with patch.dict(os.environ, {'SAWN_DB': str(Path(cls.temp.name) / 'initial.db')}):
            cls.module = importlib.import_module('app')
        cls.app = cls.module.app
        cls.app.config.update(TESTING=True)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        self.module.DB = Path(self.temp.name) / f'{self._testMethodName}.db'
        self.module.setup()
        self.client = self.app.test_client()
        with self.app.app_context():
            con = self.module.db()
            con.execute("INSERT INTO devices(asset_tag,name) VALUES ('PC-001','Test workstation')")
            con.execute("INSERT INTO tickets(device_id,issue,status) VALUES (1,'Disk issue','قيد الصيانة')")
            con.execute("INSERT INTO tasks(title,assigned_to,assigned_by) VALUES ('Private tech task',2,1)")
            con.execute("INSERT INTO tasks(title,assigned_to,assigned_by) VALUES ('Employee task',3,1)")
            con.commit()

    def login(self, name='admin', password='Sawn@2026'):
        response = self.client.post('/login', data={'username':name,'password':password})
        self.assertEqual(response.status_code,302)
        with self.client.session_transaction() as session:
            return {'X-CSRF-Token':session['csrf']}

    def ask(self, message, headers, **kwargs):
        return self.client.post('/api/assistant', json={'message':message,**kwargs}, headers=headers)

    def test_authentication_and_csrf_are_required(self):
        self.assertEqual(self.ask('help',{}).status_code,401)
        self.assertEqual(self.client.get('/').status_code,302)
        headers = self.login()
        self.assertEqual(self.ask('help',{}).status_code,400)
        self.assertEqual(self.ask('help',headers).status_code,200)
        self.client.get('/logout')  # GET must not log the user out.
        with self.client.session_transaction() as session:
            csrf = session['csrf']
        self.client.post('/logout',data={'_csrf':csrf})
        self.assertEqual(self.ask('help',headers).status_code,401)

    def test_summary_only_counts_the_current_users_tasks(self):
        headers = self.login('employee','Employee@2026')
        payload = self.ask('my summary',headers,language='en').get_json()
        self.assertIn('Registered devices: 1',payload['reply'])
        self.assertIn('Your remaining assigned tasks: 1',payload['reply'])
        self.assertNotIn('Private tech task',payload['reply'])
        self.assertNotIn('/admin',[x['url'] for x in payload['links']])
        self.assertEqual(self.client.get('/admin').status_code,403)

    def test_device_and_ticket_lookup(self):
        headers = self.login()
        device = self.ask('device PC-001',headers).get_json()
        self.assertIn('Test workstation',device['reply'])
        self.assertEqual(device['links'][0]['url'],'/devices/1')
        ticket = self.ask('بلاغ 1',headers).get_json()
        self.assertIn('قيد الصيانة',ticket['reply'])
        self.assertIn('Disk issue',ticket['reply'])
        self.assertIn('لم أجد', self.ask('بلاغ 999',headers).get_json()['reply'])

    def test_guides_and_role_specific_links(self):
        headers = self.login()
        self.assertTrue(any(x['url']=='/admin' for x in self.ask('task',headers).get_json()['links']))
        for message, endpoint in [('جهازي بطيء','/tickets#newTicket'),('الصيانة الدورية','/maintenance'),('تقرير','/reports'),('دعم','/support')]:
            reply = self.ask(message,headers).get_json()
            self.assertIn(endpoint,[x['url'] for x in reply['links']])

    def test_invalid_payloads_and_read_only_behavior(self):
        headers = self.login()
        for body in [[], {'message': []},{'message':''},{'message':'x'*601}]:
            self.assertEqual(self.client.post('/api/assistant',json=body,headers=headers).status_code,400)
        self.assertEqual(self.client.post('/api/assistant',data='not json',headers=headers).status_code,400)
        self.assertEqual(self.ask("'; DROP TABLE users; --",headers).status_code,200)
        self.assertEqual(self.ask('ticket '+('9'*500),headers).status_code,200)
        with self.app.app_context():
            self.assertEqual(self.module.db().execute('SELECT count(*) FROM users').fetchone()[0],3)
            self.assertEqual(self.module.db().execute('SELECT count(*) FROM tickets').fetchone()[0],1)

    def test_all_pages_and_original_create_workflow(self):
        headers = self.login()
        for route in ['/','/devices','/devices/1','/tickets','/technicians','/tasks','/maintenance','/news','/notifications','/reports','/support','/admin']:
            self.assertEqual(self.client.get(route).status_code,200,route)
        home = self.client.get('/').get_data(as_text=True)
        self.assertIn('newsStrip',home)
        self.assertIn('class="overview"',home)
        self.assertNotIn('<script',home.lower())
        self.assertNotIn('bottomGrid',home)
        response = self.client.post('/devices',data={'asset_tag':'PC-002','name':'New computer'},headers=headers,follow_redirects=True)
        self.assertEqual(response.status_code,200)
        self.assertIn('New computer',response.get_data(as_text=True))


    def test_server_search_and_literal_filtering(self):
        self.login()
        for route in ['/search?q=PC-001','/devices?q=PC-001','/tickets?q=Disk']:
            response=self.client.get(route)
            self.assertEqual(response.status_code,200)
            self.assertIn('PC-001',response.get_data(as_text=True))
        for query in ['no-such-device','%','_']:
            response=self.client.get('/devices',query_string={'q':query})
            self.assertEqual(response.status_code,200)
            self.assertNotIn('Test workstation',response.get_data(as_text=True))

    def test_html_assistant_is_private_clearable_and_csrf_protected(self):
        headers=self.login()
        self.assertEqual(self.client.post('/assistant',data={'message':'ملخص حسابي'}).status_code,400)
        response=self.client.post('/assistant',data={'message':'ملخص حسابي'},headers=headers,follow_redirects=True)
        self.assertEqual(response.status_code,200)
        self.assertIn('الأجهزة المسجلة: 1',response.get_data(as_text=True))
        self.assertNotIn('<script',response.get_data(as_text=True).lower())
        other=self.app.test_client()
        other.post('/login',data={'username':'employee','password':'Employee@2026'})
        self.assertNotIn('الأجهزة المسجلة: 1',other.get('/assistant').get_data(as_text=True))
        response=self.client.post('/assistant',data={'action':'clear'},headers=headers,follow_redirects=True)
        self.assertNotIn('الأجهزة المسجلة: 1',response.get_data(as_text=True))

    def test_preferences_and_intro_survive_login_without_scripts(self):
        response=self.client.get('/login')
        self.assertIn('class="welcomeIntro"',response.get_data(as_text=True))
        self.assertIn('class="welcomeIntro"',self.client.get('/login').get_data(as_text=True))
        with self.client.session_transaction() as state:csrf=state['csrf']
        response=self.client.post('/preferences',data={'_csrf':csrf,'language':'en','theme':'dark','return_to':'/login'},follow_redirects=True)
        self.assertIn('lang="en"',response.get_data(as_text=True))
        self.assertIn('data-theme="dark"',response.get_data(as_text=True))
        headers=self.login()
        home=self.client.get('/').get_data(as_text=True)
        self.assertNotIn('class="welcomeIntro"',home)
        self.assertIn('class="welcomeIntro"',self.client.get('/').get_data(as_text=True))
        self.assertIn('Device Management',home)
        self.assertIn('class="topNavigation"',home)
        for target in ['https://example.com','//example.com','/\\example.com','/%5c%5cexample.com']:
            response=self.client.post('/preferences',data={'return_to':target},headers=headers)
            self.assertEqual(response.headers['Location'],'/')

    def test_source_and_rendered_pages_contain_no_browser_scripts(self):
        from html.parser import HTMLParser
        class ScriptScanner(HTMLParser):
            def handle_starttag(parser,tag,attrs):
                self.assertNotEqual(tag.lower(),'script')
                for key,value in attrs:
                    self.assertFalse(key.lower().startswith('on'),(tag,key))
                    self.assertFalse((value or '').strip().lower().startswith('javascript:'),(tag,key))
        self.login()
        routes=['/','/devices','/tickets','/maintenance','/news','/reports','/assistant','/search?q=PC-001']
        for route in routes:ScriptScanner().feed(self.client.get(route).get_data(as_text=True))
        root=Path(self.module.__file__).parent
        self.assertFalse(list(root.rglob('*.js')))
        self.assertFalse(list(root.rglob('*.mjs')))


    def test_existing_database_is_preserved_when_chat_table_is_added(self):
        import sqlite3
        original=self.module.DB
        self.module.DB=Path(self.temp.name)/'legacy.db'
        schema=(Path(self.module.__file__).parent/'schema.sql').read_text().split('CREATE TABLE IF NOT EXISTS assistant_messages(')[0]
        con=sqlite3.connect(self.module.DB)
        con.executescript(schema)
        con.execute("INSERT INTO users(username,password_hash,display_name,role) VALUES ('legacy','preserved hash','Legacy employee','employee')")
        con.execute("INSERT INTO devices(asset_tag,name) VALUES ('LEGACY-01','Keep this device')")
        con.execute("INSERT INTO tickets(device_id,issue) VALUES (1,'Keep this repair')")
        con.commit();con.close()
        self.module.setup()
        from automation import backup_directory
        copies=list(backup_directory(self.module.DB).glob('sawn-before-upgrade-*.sqlite3'))
        self.assertEqual(len(copies),1)
        historical=sqlite3.connect(copies[0])
        try:
            self.assertNotIn('assigned_to',{row[1] for row in historical.execute('PRAGMA table_info(tickets)')})
            self.assertEqual(historical.execute('SELECT name FROM devices').fetchone()[0],'Keep this device')
        finally:historical.close()
        with self.app.app_context():
            con=self.module.db()
            self.assertEqual(con.execute("SELECT name FROM devices WHERE asset_tag='LEGACY-01'").fetchone()[0],'Keep this device')
            self.assertEqual(con.execute("SELECT issue FROM tickets WHERE id=1").fetchone()[0],'Keep this repair')
            self.assertEqual(con.execute("SELECT password_hash FROM users WHERE username='legacy'").fetchone()[0],'preserved hash')
            self.assertEqual(con.execute('SELECT count(*) FROM assistant_messages').fetchone()[0],0)
        self.module.DB=original

    def test_browser_script_policy_and_chat_escaping(self):
        headers=self.login()
        response=self.client.post('/assistant',data={'message':'<script>alert(1)</script>'},headers=headers,follow_redirects=True)
        self.assertIn("script-src 'none'",response.headers['Content-Security-Policy'])
        page=response.get_data(as_text=True)
        self.assertIn('&lt;script&gt;',page)
        self.assertNotIn('<script',page)


    def test_refresh_logout_and_internal_navigation_loading(self):
        headers=self.login()
        first=self.client.get('/').get_data(as_text=True)
        self.assertNotIn('class="welcomeIntro"',first)
        refreshed=self.client.get('/').get_data(as_text=True)
        self.assertIn('class="welcomeIntro"',refreshed)
        response=self.client.get('/go',query_string={'to':'/devices'},follow_redirects=True)
        self.assertEqual(response.status_code,200)
        self.assertNotIn('class="welcomeIntro"',response.get_data(as_text=True))
        self.assertEqual(response.request.path,'/devices')
        self.assertIn('class="welcomeIntro"',self.client.get('/devices').get_data(as_text=True))
        response=self.client.get('/go',query_string={'to':'/search','q':'PC-001'},follow_redirects=True)
        self.assertIn('PC-001',response.get_data(as_text=True))
        self.assertNotIn('class="welcomeIntro"',response.get_data(as_text=True))
        response=self.client.post('/logout',headers=headers,follow_redirects=True)
        self.assertIn('class="welcomeIntro"',response.get_data(as_text=True))

    def test_grouped_services_ticker_and_staff_directory(self):
        self.login()
        with self.app.app_context():
            self.module.db().execute("INSERT INTO announcements(title_ar,title_en) VALUES ('ورشة صيانة الأجهزة','Device care workshop')")
            self.module.db().commit()
        page=self.client.get('/').get_data(as_text=True)
        self.assertIn('class="supportMenu"',page)
        self.assertIn('class="tickerTrack"',page)
        self.assertIn('id="pauseNews"',page)
        self.assertEqual(page.count('class="tickerGroup"'),2)
        team=self.client.get('/team').get_data(as_text=True)
        self.assertIn('مدير النظام',team)
        self.assertIn('أحمد - فني صيانة',team)
        self.assertIn('سالم - موظف',team)
        self.assertNotIn('password_hash',team)
        for target in ['https://example.com','//example.com','/go','/logout','/static/style.css','/missing']:
            self.assertEqual(self.client.get('/go',query_string={'to':target}).status_code,400,target)


if __name__ == '__main__':
    unittest.main()

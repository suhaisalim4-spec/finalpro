"""Requirements from the uploaded analysis and proposal: real, end-to-end server checks."""
import importlib
import json
import os
import sqlite3
import tempfile
import threading
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch
from werkzeug.security import generate_password_hash,check_password_hash


class RequirementsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        with patch.dict(os.environ,{'SAWN_DB':str(Path(cls.temp.name)/'initial.db')}):cls.module=importlib.import_module('app')
        cls.app=cls.module.app;cls.app.config['TESTING']=True

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def setUp(self):
        self.module.DB=Path(self.temp.name)/(self._testMethodName+'.db');self.module.setup()
        self.client=self.app.test_client()
        with self.app.app_context():
            con=self.module.db()
            con.execute("INSERT INTO users(username,password_hash,display_name,role) VALUES ('tech2',?,'فني ثان','technician')",(generate_password_hash('TechTwo@2026'),))
            con.execute("INSERT INTO devices(asset_tag,name,serial_number) VALUES ('REQ-001','Requirements device','SERIAL-001')")
            con.commit()

    def login(self,username='admin',password='Sawn@2026',client=None):
        client=client or self.client
        self.assertEqual(client.post('/login',data={'username':username,'password':password}).status_code,302)
        with client.session_transaction() as state:return {'X-CSRF-Token':state['csrf']}

    def create(self):
        headers=self.login('employee','Employee@2026')
        response=self.client.post('/tickets',data={'device_id':1,'issue':'Repair the test workstation','assigned_to':2},headers=headers)
        self.assertEqual(response.status_code,302)
        with self.app.app_context():return self.module.db().execute('SELECT id FROM tickets ORDER BY id DESC').fetchone()[0]

    def test_technician_assignment_permissions_duplicates_and_notifications(self):
        ticket=self.create()
        with self.app.app_context():
            con=self.module.db();row=con.execute('SELECT * FROM tickets WHERE id=?',(ticket,)).fetchone()
            self.assertEqual((row['assigned_to'],row['created_by']),(2,3))
            self.assertEqual(con.execute('SELECT user_id FROM notifications').fetchone()[0],2)
            self.assertEqual(con.execute('SELECT event_type FROM ticket_events').fetchone()[0],'created')
        headers=self.login('employee','Employee@2026')
        self.client.post('/tickets',data={'device_id':1,'issue':'Repair the test workstation','assigned_to':2},headers=headers)
        with self.app.app_context():self.assertEqual(self.module.db().execute('SELECT count(*) FROM tickets').fetchone()[0],1)
        self.assertEqual(self.client.post(f'/tickets/{ticket}/status',data={'status':'مكتمل'},headers=headers).status_code,403)
        headers=self.login('tech2','TechTwo@2026')
        self.assertEqual(self.client.post(f'/tickets/{ticket}/status',data={'status':'قيد الصيانة'},headers=headers).status_code,403)
        self.assertEqual(self.client.get(f'/tickets/{ticket}').status_code,404)
        self.assertNotIn('Repair the test workstation',self.client.get('/search?q=Repair').get_data(as_text=True))
        api=self.client.post('/api/assistant',json={'message':f'ticket {ticket}','language':'en'},headers=headers)
        self.assertNotIn('Repair the test workstation',api.get_json()['reply'])
        headers=self.login('tech','Tech@2026')
        self.assertEqual(self.client.post(f'/tickets/{ticket}/status',data={'status':'قيد الصيانة','note':'Diagnosis started'},headers=headers).status_code,302)
        with self.app.app_context():self.assertEqual(self.module.db().execute('SELECT status FROM tickets').fetchone()[0],'قيد الصيانة')

    def test_repair_completion_history_device_state_and_reopening(self):
        ticket=self.create();headers=self.login('tech','Tech@2026')
        self.client.post(f'/tickets/{ticket}/status',data={'status':'مكتمل'},headers=headers)
        with self.app.app_context():self.assertEqual(self.module.db().execute('SELECT status FROM tickets').fetchone()[0],'جديد')
        self.client.post(f'/tickets/{ticket}/status',data={'status':'قيد الصيانة','note':'Checking disk'},headers=headers)
        self.assertIn('قيد الصيانة',self.client.get('/devices/1').get_data(as_text=True))
        self.client.post(f'/tickets/{ticket}/status',data={'status':'مكتمل','resolution':'Replaced the failed disk and verified startup'},headers=headers)
        with self.app.app_context():
            row=self.module.db().execute('SELECT * FROM tickets').fetchone()
            self.assertTrue(row['completed_at']);self.assertIn('failed disk',row['resolution'])
        page=self.client.get(f'/tickets/{ticket}').get_data(as_text=True)
        self.assertIn('Checking disk',page);self.assertIn('Replaced the failed disk',page)
        self.assertIn('لا توجد بلاغات مفتوحة',self.client.get('/devices/1').get_data(as_text=True))
        headers=self.login();self.client.post(f'/tickets/{ticket}/status',data={'status':'جديد','note':'Reopened after a follow-up issue'},headers=headers)
        with self.app.app_context():self.assertIsNone(self.module.db().execute('SELECT completed_at FROM tickets').fetchone()[0])
        page=self.client.get(f'/tickets/{ticket}').get_data(as_text=True)
        self.assertIn('Replaced the failed disk',page);self.assertIn('Reopened after a follow-up issue',page)

    def test_reassignment_revokes_previous_technicians_write_access(self):
        ticket=self.create();headers=self.login()
        self.client.post(f'/tickets/{ticket}/assign',data={'assigned_to':4},headers=headers)
        headers=self.login('tech','Tech@2026')
        self.assertEqual(self.client.post(f'/tickets/{ticket}/status',data={'status':'قيد الصيانة'},headers=headers).status_code,403)
        headers=self.login('tech2','TechTwo@2026')
        self.assertEqual(self.client.post(f'/tickets/{ticket}/status',data={'status':'قيد الصيانة'},headers=headers).status_code,302)
        with self.app.app_context():self.assertEqual(self.module.db().execute("SELECT count(*) FROM ticket_events WHERE event_type='assigned'").fetchone()[0],1)

    def test_validation_rejects_invalid_references_dates_and_duplicates(self):
        headers=self.login()
        self.client.post('/devices',data={'asset_tag':'REQ-001','name':'Duplicate'},headers=headers)
        self.client.post('/devices',data={'asset_tag':'REQ-002','name':'Duplicate serial','serial_number':'SERIAL-001'},headers=headers)
        for target in [3,999]:self.client.post('/tickets',data={'device_id':1,'issue':'Invalid assignee','assigned_to':target},headers=headers)
        self.client.post('/admin',data={'title':'Bad date task','assigned_to':3,'due_date':'not-a-date'},headers=headers)
        self.client.post('/maintenance',data={'device_id':999,'kind':'Inspect cooling','due_date':'2026-10-30','interval_days':90},headers=headers)
        self.client.post('/maintenance',data={'device_id':1,'kind':'Inspect cooling','due_date':'broken','interval_days':90},headers=headers)
        with self.app.app_context():
            con=self.module.db()
            for table,count in [('devices',1),('tickets',0),('tasks',0),('schedules',0)]:self.assertEqual(con.execute('SELECT count(*) FROM '+table).fetchone()[0],count)

    def test_account_creation_hashing_deactivation_and_supervisor_only_pages(self):
        headers=self.login()
        self.client.post('/users',data={'username':'newtech','display_name':'فني جديد','password':'TestAccount@2026','role':'technician'},headers=headers)
        with self.app.app_context():
            row=self.module.db().execute("SELECT * FROM users WHERE username='newtech'").fetchone();new_id=row['id']
            self.assertNotEqual(row['password_hash'],'TestAccount@2026');self.assertTrue(check_password_hash(row['password_hash'],'TestAccount@2026'))
        other=self.app.test_client();self.login('newtech','TestAccount@2026',other)
        self.client.post(f'/users/{new_id}/active',headers=headers)
        self.assertEqual(other.get('/tickets').status_code,302)
        self.assertEqual(self.client.post('/users/1/active',headers=headers).status_code,400)
        headers=self.login('employee','Employee@2026')
        for path in ['/users','/backups','/backups/download','/reports','/reports/export?start=2026-10-19']:
            self.assertEqual(self.client.get(path).status_code,403,path)

    def test_weekly_generation_is_automatic_idempotent_and_respects_local_week(self):
        from automation import generate_due_reports
        ticket=self.create()
        with self.app.app_context():
            con=self.module.db()
            con.execute("UPDATE devices SET created_at='2026-10-20 10:00:00'")
            con.execute("UPDATE tickets SET created_at='2026-10-20 10:00:00',status='مكتمل',completed_at='2026-10-25 23:30:00',resolution='Fixed'")
            con.execute("UPDATE ticket_events SET created_at='2026-10-20 10:00:00'");con.commit()
            self.assertGreater(generate_due_reports(con,date(2026,10,26)),0)
            row=con.execute("SELECT * FROM weekly_reports WHERE week_start='2026-10-19'").fetchone()
            payload=json.loads(row['payload']);self.assertEqual(len(payload['repairs']),1)
            self.assertEqual(len(payload['completed']),0) # 23:30 UTC Sunday is Monday locally.
            self.assertEqual(generate_due_reports(con,date(2026,10,26)),0)
            con.execute("UPDATE tickets SET issue='Changed after generation'");con.commit()
            self.assertNotIn('Changed after generation',con.execute('SELECT payload FROM weekly_reports WHERE id=?',(row['id'],)).fetchone()[0])
        headers=self.login();response=self.client.get('/reports/archive/'+str(row['id']))
        self.assertEqual(response.status_code,200)
        export=self.client.get('/reports/export?id='+str(row['id']));self.assertEqual(export.status_code,200)
        self.assertIn('Repair the test workstation',export.data.decode('utf-8-sig'))

    def test_daily_backups_and_admin_download_are_real_sqlite_databases(self):
        from automation import daily_backup
        self.create()
        first=daily_backup(self.module.DB,date(2026,10,26));mtime=first.stat().st_mtime_ns
        self.assertEqual(daily_backup(self.module.DB,date(2026,10,26)),first);self.assertEqual(first.stat().st_mtime_ns,mtime)
        con=sqlite3.connect(first);self.assertEqual(con.execute('PRAGMA integrity_check').fetchone()[0],'ok');self.assertEqual(con.execute('SELECT count(*) FROM tickets').fetchone()[0],1);con.close()
        self.login();response=self.client.get('/backups/download');self.assertTrue(response.data.startswith(b'SQLite format 3\x00'))
        downloaded=Path(self.temp.name)/'downloaded.db';downloaded.write_bytes(response.data)
        con=sqlite3.connect(downloaded);self.assertEqual(con.execute('SELECT count(*) FROM devices').fetchone()[0],1);con.close()

    def test_background_worker_starts_once_without_waiting_for_a_page_to_generate_report(self):
        from automation import start_worker
        done=threading.Event();seen=[]
        def fake_run(database):seen.append(database);done.set()
        self.app.config['TESTING']=False
        try:
            with patch('automation.run_due',fake_run):
                start_worker(self.app,self.module.DB);start_worker(self.app,self.module.DB)
                self.assertTrue(done.wait(2));thread,stop=self.app.extensions['sawn_worker'];stop.set();thread.join(2)
                self.assertEqual(seen,[self.module.DB])
        finally:
            self.app.config['TESTING']=True;self.app.extensions.pop('sawn_worker',None)

    def test_homepage_is_ordered_and_intro_has_no_skip_control(self):
        self.login()
        page=self.client.get('/').get_data(as_text=True)
        self.assertIn('class="homeHeading"',page);self.assertIn('class="homeWorkGrid"',page)
        self.assertNotIn('class="heroArt"',page);self.assertNotIn('class="assistantInvite"',page)
        refreshed=self.client.get('/').get_data(as_text=True)
        self.assertIn('class="welcomeIntro"',refreshed);self.assertNotIn('class="introSkip"',refreshed)


    def test_standard_startup_generates_report_and_backup_without_any_http_request(self):
        import subprocess,time
        database=Path(self.temp.name)/'startup-alone.db'
        backup_dir=Path(self.temp.name)/'startup-backups'
        environment=os.environ.copy()
        environment.update(SAWN_DB=str(database),SAWN_BACKUP_DIR=str(backup_dir),SAWN_PORT='0')
        process=subprocess.Popen([__import__('sys').executable,self.module.__file__],cwd=Path(self.module.__file__).parent,env=environment,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            ready=False
            for _ in range(60):
                if database.exists() and list(backup_dir.glob('sawn-backup-*.sqlite3')):
                    con=sqlite3.connect(database)
                    try:ready=con.execute('SELECT count(*) FROM weekly_reports').fetchone()[0]>0
                    finally:con.close()
                    if ready:break
                if process.poll() is not None:break
                time.sleep(.1)
            self.assertTrue(ready,'The standard app.py command must start automation without a page visit')
        finally:
            process.terminate()
            try:process.wait(timeout=3)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)


if __name__=='__main__':unittest.main()

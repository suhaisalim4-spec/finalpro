"""Clear Arabic report presentation and portable, server-generated PDF output."""
import io
import json
import os
from datetime import datetime
from pathlib import Path
from arabic_reshaper import reshape
from bidi.algorithm import get_display
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Flowable,Spacer,HRFlowable
from domain import LOCAL_TZ
from recurrence import ACTIONS

ROOT=Path(__file__).resolve().parent


def date_label(value):
    if not value:return 'غير مسجّل'
    try:
        parsed=datetime.fromisoformat(str(value))
        if len(str(value))>10:
            if parsed.tzinfo is None:
                from datetime import timezone
                parsed=parsed.replace(tzinfo=timezone.utc)
            parsed=parsed.astimezone(LOCAL_TZ)
        months=('يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر')
        return f'{parsed.day} {months[parsed.month-1]} {parsed.year}'
    except (ValueError,TypeError):return str(value)


def present_report(payload):
    records={}
    for item in payload.get('repairs',[]):records[item['id']]=dict(item)
    for item in payload.get('completed',[]):
        row=records.setdefault(item['id'],{})
        row.update(item);row['status']='مكتمل'
    services=payload.get('services',[])
    clean=[]
    for ticket_id,item in sorted(records.items()):
        related=[row for row in services if row.get('ticket_id')==ticket_id]
        try:actions=json.loads(item.get('maintenance_actions') or '[]')
        except (ValueError,TypeError):actions=[]
        action_names=[ACTIONS[code] for code in actions if code in ACTIONS]
        if not action_names:action_names=list(dict.fromkeys(ACTIONS.get(row['service_code'],'صيانة عامة') for row in related))
        done=item.get('status')=='مكتمل' or bool(item.get('completed_at'))
        clean.append(dict(id=ticket_id,asset=item.get('asset_tag') or 'غير مسجّل',device=item.get('device_name') or 'غير مسجّل',
            issue=item.get('issue') or 'لم يُسجّل وصف للعطل',technician=item.get('assignee') or 'لم يُحدد فني',
            status=item.get('status') or ('مكتمل' if done else 'غير مسجّل'),created=date_label(item.get('created_at')),
            completed=date_label(item.get('completed_at')) if done else 'لم ينتهِ بعد',
            work=(item.get('resolution') or '').strip() or ('لا يتوفر وصف للإصلاح في هذا السجل القديم.' if done else 'لم يُسجّل إصلاح مكتمل لهذا البلاغ بعد.'),
            actions='، '.join(action_names) or 'غير محدد',next_due=date_label(min(row['next_due'] for row in related)) if related else 'لا يوجد موعد مسجّل ضمن هذا التقرير'))
    return dict(start=date_label(payload.get('start')),end=date_label(payload.get('end')),records=clean,
        new_count=len(payload.get('repairs',[])),completed_count=len(payload.get('completed',[])),
        services=services,tasks=payload.get('tasks',[]),upkeep=payload.get('upkeep',[]),registered=payload.get('devices',0))


def report_fonts():
    windows=Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'
    regular=windows/'times.ttf';bold=windows/'timesbd.ttf'
    if not regular.is_file():
        regular=ROOT/'static/fonts/NotoNaskhArabic-Regular.ttf'
        bold=ROOT/'static/fonts/NotoNaskhArabic-Bold.ttf'
    if not bold.is_file():bold=regular
    for name,path in [('SawnFinal',regular),('SawnFinalBold',bold)]:
        if name not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(name,str(path),shapable=False))
    # Arabic fonts can omit Latin asset tags and punctuation. Embed a serif
    # companion for those glyphs rather than silently dropping identifiers.
    for name,filename in [('SawnLatin','LiberationSerif-Regular.ttf'),('SawnLatinBold','LiberationSerif-Bold.ttf')]:
        if name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(name,str(ROOT/'static/fonts'/filename),shapable=False))
    return 'SawnFinal','SawnFinalBold'


def visual(text):
    return get_display(reshape(str(text)),base_dir='R')


def visual_runs(text,font):
    primary=pdfmetrics.getFont(font).face.charToGlyph
    fallback='SawnLatinBold' if font.endswith('Bold') else 'SawnLatin'
    result=[]
    for character in visual(text):
        selected=font if ord(character) in primary else fallback
        if result and result[-1][0]==selected:result[-1]=(selected,result[-1][1]+character)
        else:result.append((selected,character))
    return result


def text_width(text,font,size):
    return sum(pdfmetrics.stringWidth(value,name,size) for name,value in visual_runs(text,font))


def draw_right(canvas,x,y,text,font,size):
    runs=visual_runs(text,font)
    x-=sum(pdfmetrics.stringWidth(value,name,size) for name,value in runs)
    for name,value in runs:
        canvas.setFont(name,size);canvas.drawString(x,y,value)
        x+=pdfmetrics.stringWidth(value,name,size)


class ArabicText(Flowable):
    """Wrap logical Arabic text first, then shape/reorder each complete line."""
    def __init__(self,text,size=14,font='SawnFinal',color='#19363c',leading=None,lines=None):
        Flowable.__init__(self)
        self.text=str(text or '—');self.size=size;self.font=font;self.color=colors.HexColor(color)
        self.leading=leading or size*1.65;self.logical_lines=lines
    def _wrap_lines(self,width):
        if self.logical_lines is not None:return self.logical_lines
        lines=[]
        for paragraph in self.text.splitlines() or ['']:
            current=''
            for word in paragraph.split():
                candidate=(current+' '+word).strip()
                if text_width(candidate,self.font,self.size)<=width:
                    current=candidate;continue
                if current:lines.append(current);current=''
                # Long identifiers or pasted text must fit inside the page too.
                for character in word:
                    if current and text_width(current+character,self.font,self.size)>width:
                        lines.append(current);current=''
                    current+=character
            lines.append(current)
        return lines
    def wrap(self,availWidth,availHeight):
        self.width=availWidth;self.lines=self._wrap_lines(availWidth)
        self.height=len(self.lines)*self.leading
        return self.width,self.height
    def split(self,availWidth,availHeight):
        lines=self._wrap_lines(availWidth);count=int(availHeight//self.leading)
        if count<1:return []
        if count>=len(lines):return [self]
        return [ArabicText('',self.size,self.font,color=self.color.hexval(),lines=lines[:count],leading=self.leading),ArabicText('',self.size,self.font,color=self.color.hexval(),lines=lines[count:],leading=self.leading)]
    def draw(self):
        self.canv.setFont(self.font,self.size);self.canv.setFillColor(self.color)
        for index,line in enumerate(self.lines):draw_right(self.canv,self.width,self.height-(index+1)*self.leading+self.leading*.25,line,self.font,self.size)


def render_report_pdf(payload,generated_at=None):
    regular,bold=report_fonts();view=present_report(payload)
    output=io.BytesIO();page_width,page_height=A4
    document=SimpleDocTemplate(output,pagesize=A4,rightMargin=45,leftMargin=45,topMargin=96,bottomMargin=55,title='صَوْن — تقرير الصيانة',author='صَوْن')
    def page_frame(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#177a70'));canvas.setLineWidth(1)
        canvas.line(45,page_height-77,page_width-45,page_height-77)
        canvas.setFillColor(colors.HexColor('#177a70'))
        edge=page_width-45;baseline=page_height-48
        canvas.saveState();canvas.translate(edge-35,baseline+29);canvas.scale(.72,-.72)
        canvas.setStrokeColor(colors.HexColor('#177a70'));canvas.setLineWidth(2.4)
        frame=canvas.beginPath();frame.moveTo(31,7);frame.lineTo(12,7)
        frame.curveTo(9.24,7,7,9.24,7,12);frame.lineTo(7,31)
        frame.curveTo(7,33.76,9.24,36,12,36);frame.lineTo(31,36)
        frame.curveTo(33.76,36,36,33.76,36,31);frame.lineTo(36,20)
        canvas.drawPath(frame,stroke=1,fill=0)
        canvas.line(16,41,28,41);canvas.line(22,36,22,41)
        tool=canvas.beginPath();tool.moveTo(38,5);tool.curveTo(32,2,26,8,28,15)
        tool.lineTo(18,25);tool.curveTo(14.5,28.5,19.5,33.5,23,30)
        tool.lineTo(33,20);tool.curveTo(40,22,46,16,43,10)
        tool.lineTo(37,16);tool.lineTo(32,11);tool.close()
        canvas.setFillColor(colors.HexColor('#e3f1ec'));canvas.drawPath(tool,stroke=1,fill=1)
        canvas.setFillColor(colors.HexColor('#177a70'));canvas.circle(13,13,2,stroke=0,fill=1)
        canvas.restoreState();draw_right(canvas,edge-43,baseline,'صَوْن',bold,26)
        canvas.setFont(regular,12);canvas.setFillColor(colors.HexColor('#526c6d'));canvas.drawString(45,page_height-47,visual('تقرير الصيانة'))
        canvas.setFont(regular,11);canvas.drawRightString(page_width-45,30,visual(f'صفحة {doc.page}'))
        canvas.drawString(45,30,visual('صَوْن لإدارة صيانة الأجهزة'));canvas.restoreState()
    story=[]
    def text(value,size=14,strong=False,color='#19363c'):
        item=ArabicText(value,size,bold if strong else regular,color);item.keepWithNext=strong
        gap=Spacer(1,5);gap.keepWithNext=strong
        story.extend([item,gap])
    def section(title):
        story.append(Spacer(1,10));text(title,18,True,'#177a70')
    text('تقرير الصيانة الأسبوعي',22,True)
    text(f"الفترة: من {view['start']} إلى {view['end']}",15)
    if generated_at:text('تاريخ إعداد النسخة: '+date_label(generated_at),12,color='#526c6d')
    section('ملخص الفترة')
    text(f"سُجّل خلال هذه الفترة {view['new_count']} بلاغ جديد، وأُنجز {view['completed_count']} إصلاح.")
    text(f"الأجهزة التي أُضيفت: {view['registered']} جهاز. أعمال الصيانة المنفذة: {len(view['services'])} عمل.")
    section('تفاصيل الأجهزة والإصلاحات')
    if not view['records']:text('لا توجد بلاغات جديدة أو إصلاحات مكتملة خلال هذه الفترة.')
    for index,row in enumerate(view['records'],1):
        text(f"{index}. البلاغ رقم {row['id']} — الجهاز {row['asset']}",17,True)
        for label,key in [('اسم الجهاز','device'),('العطل المسجّل','issue'),('الفني المسؤول','technician'),('تاريخ تسجيل البلاغ','created'),('حالة البلاغ','status'),('ما العمل الذي أُنجز؟','work'),('نوع الصيانة','actions'),('تاريخ إكمال الإصلاح','completed'),('الصيانة القادمة','next_due')]:
            text(f'{label}: {row[key]}')
        story.append(HRFlowable(width='100%',thickness=.5,color=colors.HexColor('#d6e3dc'),spaceBefore=6,spaceAfter=14))
    section('أعمال الصيانة المنفذة')
    if not view['services']:text('لم تُسجّل أعمال صيانة دورية منفذة خلال هذه الفترة.')
    for row in view['services']:
        text(f"الجهاز: {row['asset_tag']} — {ACTIONS.get(row['service_code'],'صيانة عامة')}",15,True)
        text(f"تاريخ التنفيذ: {date_label(row['performed_on'])}. الموعد التالي: {date_label(row['next_due'])}.")
        text('الفني: '+(row.get('technician') or 'غير مسجّل'))
        if row.get('details') and row.get('ticket_id') not in {item['id'] for item in view['records']}:
            text('تفاصيل العمل المنجز: '+row['details'])
    if view['upkeep']:
        section('مواعيد الصيانة خلال الفترة')
        for row in view['upkeep']:
            text(f"الجهاز: {row['asset_tag']} — {row['kind']} — الموعد: {date_label(row.get('due_date'))}")
    if view['tasks']:
        section('المهام المرتبطة بهذه الفترة')
        for row in view['tasks']:text(f"{row['title']} — الموظف: {row['display_name']} — الموعد: {date_label(row.get('due_date'))}")
    text('ملاحظة: يعتمد التقرير على البيانات المسجلة. عدم وجود وصف أو تاريخ يعني أنه لم يُسجّل في ذلك السجل.',11,color='#526c6d')
    document.build(story,onFirstPage=page_frame,onLaterPages=page_frame)
    return output.getvalue()

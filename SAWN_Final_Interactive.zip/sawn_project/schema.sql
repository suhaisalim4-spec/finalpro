PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, display_name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','technician','employee')), language TEXT DEFAULT 'ar', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS devices(id INTEGER PRIMARY KEY, asset_tag TEXT NOT NULL UNIQUE, name TEXT NOT NULL, model TEXT DEFAULT '', department TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY, device_id INTEGER NOT NULL REFERENCES devices(id), issue TEXT NOT NULL, technician TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'جديد' CHECK(status IN ('جديد','قيد الصيانة','مكتمل')), created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT DEFAULT '', device_id INTEGER REFERENCES devices(id), assigned_to INTEGER NOT NULL REFERENCES users(id), assigned_by INTEGER NOT NULL REFERENCES users(id), priority TEXT DEFAULT 'normal', status TEXT DEFAULT 'pending', due_date TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), title TEXT NOT NULL, message TEXT NOT NULL, link TEXT DEFAULT '/tasks', is_read INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS announcements(id INTEGER PRIMARY KEY, title_ar TEXT NOT NULL, title_en TEXT DEFAULT '', body_ar TEXT DEFAULT '', body_en TEXT DEFAULT '', category TEXT DEFAULT 'news', event_date TEXT, published INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS schedules(id INTEGER PRIMARY KEY, device_id INTEGER NOT NULL REFERENCES devices(id), kind TEXT NOT NULL, due_date TEXT NOT NULL, interval_days INTEGER DEFAULT 90, assigned_to INTEGER REFERENCES users(id), last_done TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS support_requests(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id), subject TEXT NOT NULL, message TEXT NOT NULL, status TEXT DEFAULT 'new', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS activity_log(id INTEGER PRIMARY KEY, actor_id INTEGER REFERENCES users(id), action TEXT NOT NULL, details TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned_to ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id,is_read);
CREATE INDEX IF NOT EXISTS idx_schedules_due ON schedules(due_date);

CREATE TABLE IF NOT EXISTS assistant_messages(
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    role TEXT NOT NULL CHECK(role IN ('user','bot')),
    message TEXT NOT NULL,
    links TEXT NOT NULL DEFAULT '[]',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_assistant_user ON assistant_messages(user_id,id);

CREATE TABLE IF NOT EXISTS ticket_events(
 id INTEGER PRIMARY KEY,
 ticket_id INTEGER NOT NULL REFERENCES tickets(id),
 actor_id INTEGER REFERENCES users(id),
 event_type TEXT NOT NULL CHECK(event_type IN ('created','assigned','status','note','legacy')),
 old_status TEXT, new_status TEXT,
 old_assigned_to INTEGER REFERENCES users(id), new_assigned_to INTEGER REFERENCES users(id),
 note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_ticket_event ON ticket_events(ticket_id,id);
CREATE TABLE IF NOT EXISTS weekly_reports(
 id INTEGER PRIMARY KEY, week_start TEXT NOT NULL UNIQUE, week_end TEXT NOT NULL,
 generated_at TEXT NOT NULL, payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS backup_log(
 id INTEGER PRIMARY KEY, filename TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL
);

"""Local, read-only assistant. No external AI service or API key is required."""
import json
import re
import unicodedata
from flask import g, jsonify, request, url_for, session, render_template, redirect, flash

def normalize(text):
    text = ''.join((c for c in unicodedata.normalize('NFKD', text.lower()) if not unicodedata.combining(c)))
    return text.translate(str.maketrans({'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ى': 'ي', 'ة': 'ه'}))

def register_assistant(app, db, login_required):

    @app.post('/api/assistant')
    @login_required
    def assistant_reply():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return (jsonify(error='الطلب غير صحيح'), 400)
        message = data.get('message', '')
        if not isinstance(message, str) or not message.strip() or len(message) > 600:
            return (jsonify(error='اكتب سؤالًا بين حرف واحد و٦٠٠ حرف'), 400)
        return jsonify(make_reply(message, data.get('intent')))

    def make_reply(message, intent=None):
        links = []

        def link(endpoint, ar, anchor=''):
            links.append({'label': ar, 'url': url_for(endpoint) + anchor})
        text = normalize(message)
        if intent not in {'summary', 'device', 'ticket', 'report', 'slow', 'help'}:
            intent = None
        if g.user['role'] == 'admin':
            scope, scope_args = ('1=1', ())
        elif g.user['role'] == 'technician':
            scope, scope_args = ('(assigned_to=? OR created_by=?)', (g.user['id'], g.user['id']))
        else:
            scope, scope_args = ('created_by=?', (g.user['id'],))
        asset = None
        for word in re.findall('[\\w-]+', message)[:30]:
            if any((c.isdigit() for c in word)):
                asset = db().execute('SELECT id,asset_tag,name FROM devices WHERE asset_tag=? COLLATE NOCASE', (word,)).fetchone()
                if asset:
                    break
        ticket_match = re.search('(?:#|بلاغ\\s*(?:رقم\\s*)?|ticket\\s*(?:number\\s*)?)(\\d+)', message, re.I)
        if asset:
            open_count = db().execute("SELECT count(*) FROM tickets WHERE device_id=? AND status!='مكتمل' AND " + scope, (asset['id'],) + scope_args).fetchone()[0]
            reply = f"الجهاز {asset['asset_tag']} — {asset['name']}. عدد بلاغاته المفتوحة: {open_count}. افتح سجله لمراجعة البلاغات والصيانة."
            links.append({'label': 'فتح سجل الجهاز', 'url': url_for('device_detail', id=asset['id'])})
        elif ticket_match:
            number = int(ticket_match.group(1))
            row = db().execute('SELECT id,status,issue FROM tickets WHERE id=? AND ' + scope, (number,) + scope_args).fetchone() if number <= 9223372036854775807 else None
            if row:
                reply = f"البلاغ #{row['id']} — الحالة: {row['status']}.\nوصف المشكلة: {row['issue'][:240]}"
                link('tickets', 'فتح البلاغات')
            else:
                reply = 'لم أجد بلاغًا بهذا الرقم. تأكد من الرقم في صفحة البلاغات.'
                link('tickets', 'عرض البلاغات')
        elif intent == 'summary' or any((x in text for x in ['ملخص', 'احصائي', 'summary', 'overview', 'كم بلاغ', 'كم جهاز'])):
            devices = db().execute('SELECT count(*) FROM devices').fetchone()[0]
            tickets = db().execute("SELECT count(*) FROM tickets WHERE status!='مكتمل' AND " + scope, scope_args).fetchone()[0]
            tasks = db().execute("SELECT count(*) FROM tasks WHERE assigned_to=? AND status!='completed'", (g.user['id'],)).fetchone()[0]
            reply = f"أهلًا {g.user['display_name']}!\n• الأجهزة المسجلة: {devices}\n• البلاغات المفتوحة: {tickets}\n• المهام المتبقية المسندة إليك: {tasks}\nهذه الأرقام من البيانات الحالية في النظام."
            link('tasks', 'فتح مهامي')
            link('tickets', 'متابعة البلاغات')
        elif intent == 'slow' or any((x in text for x in ['بطي', 'بطء', 'slow', 'يعلق', 'يتجمد', 'freeze'])):
            reply = 'إذا كان الجهاز بطيئًا:\n1. احفظ عملك وأعد تشغيل الجهاز.\n2. أغلق البرامج غير المستخدمة وافحص مساحة القرص.\n3. شغّل فحص الحماية المعتمد في مؤسستك.\n4. إذا استمرت المشكلة، سجّل بلاغًا مع رقم الجهاز، وقت المشكلة وأي رسالة خطأ.\nلا تحذف ملفات النظام أو تستخدم أدوات إصلاح غير موثوقة.'
            link('tickets', 'تسجيل بلاغ صيانة', '#newTicket')
        elif any((x in text for x in ['حرار', 'سخون', 'تبريد', 'heat', 'مروح'])):
            reply = 'عند ارتفاع حرارة الجهاز:\n1. احفظ عملك وتأكد من أن فتحات التهوية مكشوفة.\n2. إذا ظهرت رائحة احتراق أو انطفاء متكرر، أوقف الجهاز وتواصل مع الفني.\n3. لا تفتح الجهاز أو تبدّل المعجون الحراري دون مختص.\nسجّل بلاغًا يذكر نوع الجهاز والأعراض.'
            link('tickets', 'تسجيل بلاغ', '#newTicket')
        elif intent == 'ticket' or any((x in text for x in ['بلاغ', 'عطل', 'اصلاح', 'ticket', 'repair'])):
            reply = 'لإضافة بلاغ:\n1. افتح بلاغات الصيانة واضغط «بلاغ جديد».\n2. اختر الجهاز المسجّل.\n3. اكتب المشكلة ومتى بدأت ورسالة الخطأ إن وجدت، ثم احفظ.\nلمتابعة بلاغ معيّن اكتب مثلًا: «بلاغ 12».'
            link('tickets', 'فتح بلاغ جديد', '#newTicket')
        elif intent == 'report' or any((x in text for x in ['تقرير', 'تقارير', 'اسبوع', 'report'])):
            reply = 'افتح التقارير واختر بداية الفترة، ثم اضغط «تنزيل التقرير للطباعة». سيُحفظ ملف جاهز يعرض الجهاز والعطل والفني والإصلاح والتواريخ.'
            if g.user['role'] == 'admin':
                link('reports', 'فتح التقارير')
            else:
                reply = 'التقارير الشاملة متاحة للمشرف. يمكنك متابعة مهامك وبلاغاتك من حسابك.'
                link('tasks', 'فتح مهامي')
        elif any((x in text for x in ['مهم', 'task', 'تكليف'])):
            reply = 'في صفحة «مهامي» تجد التكليفات المتاحة لحسابك. افتح المهمة، اختر حالتها ثم اضغط «تحديث الحالة».'
            link('tasks', 'فتح مهامي')
            if g.user['role'] == 'admin':
                link('admin', 'تكليف موظف بمهمة')
        elif any((x in text for x in ['دوري', 'جدول', 'schedule', 'preventive'])):
            reply = 'عند إكمال الإصلاح أو تسجيل تنظيف أو تغيير معجون أو استبدال قطعة، يُحسب الموعد التالي تلقائيًا بعد ٩٠ يومًا من تاريخ التنفيذ. لا تحتاج إدخال موعد جديد. افتح الصيانة الدورية لمتابعة المواعيد والأعمال المنجزة.'
            link('maintenance', 'فتح الصيانة الدورية')
        elif intent == 'device' or any((x in text for x in ['جهاز', 'اجهز', 'device', 'asset'])):
            reply = 'لإضافة جهاز، افتح إدارة الأجهزة ثم «إضافة جهاز»، وأدخل رقم أصل فريدًا واسم الجهاز. للبحث عن سجل جهاز هنا، اكتب رقم الأصل مثل PC-001.'
            link('devices', 'إضافة جهاز', '#addDevice')
        elif any((x in text for x in ['مرحبا', 'اهلا', 'سلام', 'hello', 'hi', 'شكرا', 'thanks'])):
            reply = 'أهلًا بك! أستطيع شرح خطوات النظام، عرض ملخص حسابك، والبحث برقم الجهاز أو البلاغ. ماذا تحتاج؟'
        elif any((x in text for x in ['دعم', 'كلمه مرور', 'password', 'support', 'دخول'])):
            reply = 'للمشكلة التقنية أو استعادة الوصول، استخدم صفحة الدعم الفني وتواصل مع مسؤول النظام. لا ترسل كلمة مرورك في المحادثة.'
            link('support', 'فتح الدعم الفني')
        else:
            reply = 'أنا مساعد صَوْن الإرشادي المحلي. أساعدك في:\n• خطوات الأجهزة والبلاغات والتقارير والصيانة.\n• ملخص حسابك ومهامك.\n• سجل جهاز برقم الأصل، أو حالة بلاغ برقمه.\n• إرشادات أولية للبطء وارتفاع الحرارة.\nجرّب «ملخص حسابي» أو «بلاغ 12». للأسئلة الأخرى استخدم الدعم الفني.'
            link('support', 'الدعم الفني')
        return dict(reply=reply, links=links)

    @app.route('/assistant', methods=['GET', 'POST'])
    @login_required
    def assistant_page():
        if request.method == 'POST':
            if request.form.get('action') == 'clear':
                db().execute('DELETE FROM assistant_messages WHERE user_id=?', (g.user['id'],))
                db().commit()
                return redirect(url_for('assistant_page'))
            message = request.form.get('message', '').strip()
            if not message or len(message) > 600:
                flash('اكتب سؤالًا بين حرف واحد و٦٠٠ حرف', 'error')
                return redirect(url_for('assistant_page'))
            payload = make_reply(message, request.form.get('intent'))
            db().execute('INSERT INTO assistant_messages(user_id,role,message) VALUES (?,?,?)', (g.user['id'], 'user', message))
            db().execute('INSERT INTO assistant_messages(user_id,role,message,links) VALUES (?,?,?,?)', (g.user['id'], 'bot', payload['reply'], json.dumps(payload['links'], ensure_ascii=False)))
            db().execute('DELETE FROM assistant_messages WHERE user_id=? AND id NOT IN (SELECT id FROM assistant_messages WHERE user_id=? ORDER BY id DESC LIMIT 24)', (g.user['id'], g.user['id']))
            db().commit()
            return redirect(url_for('assistant_page') + '#latestReply')
        rows = db().execute('SELECT * FROM assistant_messages WHERE user_id=? ORDER BY id', (g.user['id'],)).fetchall()
        history = []
        for row in rows:
            try:
                links = json.loads(row['links'])
            except (ValueError, TypeError):
                links = []
            history.append(dict(role=row['role'], message=row['message'], links=links))
        return render_template('assistant.html', history=history)

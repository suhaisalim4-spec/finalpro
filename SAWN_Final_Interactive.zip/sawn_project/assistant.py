"""Local, read-only assistant. No external AI service or API key is required."""
import json
import re
import unicodedata
from flask import g, jsonify, request, url_for, session, render_template, redirect, flash


def normalize(text):
    text = ''.join(c for c in unicodedata.normalize('NFKD', text.lower())
                   if not unicodedata.combining(c))
    return text.translate(str.maketrans({'أ':'ا', 'إ':'ا', 'آ':'ا', 'ى':'ي', 'ة':'ه'}))


def register_assistant(app, db, login_required):
    @app.post('/api/assistant')
    @login_required
    def assistant_reply():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(error='Invalid request'), 400
        message = data.get('message', '')
        if not isinstance(message, str) or not message.strip() or len(message) > 600:
            return jsonify(error='Message must contain 1–600 characters'), 400
        return jsonify(make_reply(message, data.get('language'), data.get('intent')))

    def make_reply(message, language, intent=None):
        english = language == 'en'
        choose = lambda ar, en: en if english else ar
        links = []
        def link(endpoint, ar, en, anchor=''):
            links.append({'label': choose(ar, en), 'url': url_for(endpoint) + anchor})
        text = normalize(message)
        if intent not in {'summary', 'device', 'ticket', 'report', 'slow', 'help'}:
            intent = None
        # A specific asset tag or ticket number takes priority over general guides.
        asset = None
        for word in re.findall(r'[\w-]+', message)[:30]:
            if any(c.isdigit() for c in word):
                asset = db().execute('SELECT id,asset_tag,name FROM devices WHERE asset_tag=? COLLATE NOCASE', (word,)).fetchone()
                if asset:
                    break
        ticket_match = re.search(r'(?:#|بلاغ\s*(?:رقم\s*)?|ticket\s*(?:number\s*)?)(\d+)', message, re.I)
        if asset:
            open_count = db().execute("SELECT count(*) FROM tickets WHERE device_id=? AND status!='مكتمل'", (asset['id'],)).fetchone()[0]
            reply = choose(f"الجهاز {asset['asset_tag']} — {asset['name']}. عدد بلاغاته المفتوحة: {open_count}. افتح سجله لمراجعة البلاغات والصيانة.",
                           f"{asset['asset_tag']} — {asset['name']}. Open repair tickets: {open_count}. Open its record for repair history and maintenance.")
            links.append({'label': choose('فتح سجل الجهاز', 'Open device record'), 'url': url_for('device_detail', id=asset['id'])})
        elif ticket_match:
            number = int(ticket_match.group(1))
            row = db().execute('SELECT id,status,issue FROM tickets WHERE id=?', (number,)).fetchone() if number <= 9223372036854775807 else None
            if row:
                status_en = {'جديد':'New','قيد الصيانة':'In repair','مكتمل':'Completed'}.get(row['status'], row['status'])
                reply = choose(f"البلاغ #{row['id']} — الحالة: {row['status']}.\nوصف المشكلة: {row['issue'][:240]}",
                               f"Ticket #{row['id']} — Status: {status_en}.\nIssue: {row['issue'][:240]}")
                link('tickets', 'فتح البلاغات', 'Open tickets')
            else:
                reply = choose('لم أجد بلاغًا بهذا الرقم. تأكد من الرقم في صفحة البلاغات.', 'No ticket matches that number. Check the ticket list.')
                link('tickets', 'عرض البلاغات', 'View tickets')
        elif intent == 'summary' or any(x in text for x in ['ملخص', 'احصائي', 'summary', 'overview', 'كم بلاغ', 'كم جهاز']):
            devices = db().execute('SELECT count(*) FROM devices').fetchone()[0]
            tickets = db().execute("SELECT count(*) FROM tickets WHERE status!='مكتمل'").fetchone()[0]
            tasks = db().execute("SELECT count(*) FROM tasks WHERE assigned_to=? AND status!='completed'", (g.user['id'],)).fetchone()[0]
            reply = choose(f"أهلًا {g.user['display_name']}!\n• الأجهزة المسجلة: {devices}\n• البلاغات المفتوحة: {tickets}\n• المهام المتبقية المسندة إليك: {tasks}\nهذه الأرقام من البيانات الحالية في النظام.",
                           f"Hello {g.user['display_name']}!\n• Registered devices: {devices}\n• Open repair tickets: {tickets}\n• Your remaining assigned tasks: {tasks}\nThese figures come from the current system records.")
            link('tasks', 'فتح مهامي', 'Open my tasks')
            link('tickets', 'متابعة البلاغات', 'Track repairs')
        elif intent == 'slow' or any(x in text for x in ['بطي', 'بطء', 'slow', 'يعلق', 'يتجمد', 'freeze']):
            reply = choose('إذا كان الجهاز بطيئًا:\n1. احفظ عملك وأعد تشغيل الجهاز.\n2. أغلق البرامج غير المستخدمة وافحص مساحة القرص.\n3. شغّل فحص الحماية المعتمد في مؤسستك.\n4. إذا استمرت المشكلة، سجّل بلاغًا مع رقم الجهاز، وقت المشكلة وأي رسالة خطأ.\nلا تحذف ملفات النظام أو تستخدم أدوات إصلاح غير موثوقة.',
                           'For a slow computer:\n1. Save your work and restart.\n2. Close unused apps and check available disk space.\n3. Run your organization’s approved security scan.\n4. If it continues, report the asset tag, when it happens and any error message.\nAvoid deleting system files or running untrusted repair tools.')
            link('tickets', 'تسجيل بلاغ صيانة', 'Report a repair', '#newTicket')
        elif any(x in text for x in ['حرار', 'سخون', 'تبريد', 'heat', 'مروح']):
            reply = choose('عند ارتفاع حرارة الجهاز:\n1. احفظ عملك وتأكد من أن فتحات التهوية مكشوفة.\n2. إذا ظهرت رائحة احتراق أو انطفاء متكرر، أوقف الجهاز وتواصل مع الفني.\n3. لا تفتح الجهاز أو تبدّل المعجون الحراري دون مختص.\nسجّل بلاغًا يذكر نوع الجهاز والأعراض.',
                           'For overheating:\n1. Save your work and keep air vents clear.\n2. If you notice a burning smell or repeated shutdowns, stop using it and contact a technician.\n3. Leave internal repairs and thermal paste replacement to qualified staff.\nInclude the device and symptoms in a repair request.')
            link('tickets', 'تسجيل بلاغ', 'Create a ticket', '#newTicket')
        elif intent == 'ticket' or any(x in text for x in ['بلاغ', 'عطل', 'اصلاح', 'ticket', 'repair']):
            reply = choose('لإضافة بلاغ:\n1. افتح بلاغات الصيانة واضغط «بلاغ جديد».\n2. اختر الجهاز المسجّل.\n3. اكتب المشكلة ومتى بدأت ورسالة الخطأ إن وجدت، ثم احفظ.\nلمتابعة بلاغ معيّن اكتب مثلًا: «بلاغ 12».',
                           'To create a repair request:\n1. Open Maintenance Requests and choose New ticket.\n2. Select a registered device.\n3. Describe the issue, when it started and any error, then save.\nFor a ticket status, ask e.g. “ticket 12”.')
            link('tickets', 'فتح بلاغ جديد', 'New ticket', '#newTicket')
        elif intent == 'report' or any(x in text for x in ['تقرير', 'تقارير', 'اسبوع', 'report']):
            reply = choose('افتح التقارير واختر تاريخ بداية الأسبوع. سيظهر التقرير من البيانات المسجلة، ثم استخدم أمر الطباعة في المتصفح لحفظه PDF.',
                           'Open Reports and choose the week start date. The report uses recorded data. Use your browser’s Print command to save a PDF.')
            link('reports', 'فتح التقارير', 'Open reports')
        elif any(x in text for x in ['مهم', 'task', 'تكليف']):
            reply = choose('في صفحة «مهامي» تجد التكليفات المتاحة لحسابك. افتح المهمة، اختر حالتها ثم اضغط «تحديث الحالة».',
                           'My Tasks lists the work available to your account. Select a task status and choose Update status.')
            link('tasks', 'فتح مهامي', 'Open my tasks')
            if g.user['role'] == 'admin':
                link('admin', 'تكليف موظف بمهمة', 'Assign a task')
        elif any(x in text for x in ['دوري', 'جدول', 'schedule', 'preventive']):
            reply = choose('صفحة الصيانة الدورية تعرض المواعيد. يستطيع المدير جدولة صيانة، ويستطيع الفني المكلّف تسجيل إتمامها. بعد الإتمام ينتقل الموعد حسب الفاصل المحدد.',
                           'Preventive Care lists scheduled checks. Admins can schedule maintenance; the assigned technician can mark it done. Completion reschedules it using the configured interval.')
            link('maintenance', 'فتح الصيانة الدورية', 'Open preventive care')
        elif intent == 'device' or any(x in text for x in ['جهاز', 'اجهز', 'device', 'asset']):
            reply = choose('لإضافة جهاز، افتح إدارة الأجهزة ثم «إضافة جهاز»، وأدخل رقم أصل فريدًا واسم الجهاز. للبحث عن سجل جهاز هنا، اكتب رقم الأصل مثل PC-001.',
                           'Open Device Management, choose Add device and enter a unique asset tag and name. To look up a device here, send its asset tag, e.g. PC-001.')
            link('devices', 'إضافة جهاز', 'Add a device', '#addDevice')
        elif any(x in text for x in ['مرحبا', 'اهلا', 'سلام', 'hello', 'hi', 'شكرا', 'thanks']):
            reply = choose('أهلًا بك! أستطيع شرح خطوات النظام، عرض ملخص حسابك، والبحث برقم الجهاز أو البلاغ. ماذا تحتاج؟',
                           'Hello! I can explain workflows, show your account summary and look up an asset tag or ticket number. How can I help?')
        elif any(x in text for x in ['دعم', 'كلمه مرور', 'password', 'support', 'دخول']):
            reply = choose('للمشكلة التقنية أو استعادة الوصول، استخدم صفحة الدعم الفني وتواصل مع مسؤول النظام. لا ترسل كلمة مرورك في المحادثة.',
                           'Use Support and contact your administrator for access or technical problems. Do not share passwords in chat.')
            link('support', 'فتح الدعم الفني', 'Open support')
        else:
            reply = choose('أنا مساعد صَوْن الإرشادي المحلي. أساعدك في:\n• خطوات الأجهزة والبلاغات والتقارير والصيانة.\n• ملخص حسابك ومهامك.\n• سجل جهاز برقم الأصل، أو حالة بلاغ برقمه.\n• إرشادات أولية للبطء وارتفاع الحرارة.\nجرّب «ملخص حسابي» أو «بلاغ 12». للأسئلة الأخرى استخدم الدعم الفني.',
                           'I’m SAWN’s local guide. I can help with:\n• Devices, tickets, reports and maintenance steps.\n• Your account summary and tasks.\n• Asset-tag lookups and ticket status by number.\n• Initial guidance for slowness or overheating.\nTry “my summary” or “ticket 12”. For other questions, use Support.')
            link('support', 'الدعم الفني', 'Support')
        return dict(reply=reply, links=links)


    @app.route('/assistant', methods=['GET','POST'])
    @login_required
    def assistant_page():
        if request.method == 'POST':
            if request.form.get('action') == 'clear':
                db().execute('DELETE FROM assistant_messages WHERE user_id=?',(g.user['id'],))
                db().commit()
                return redirect(url_for('assistant_page'))
            message=request.form.get('message','').strip()
            if not message or len(message)>600:
                flash('اكتب سؤالًا بين حرف واحد و٦٠٠ حرف / Enter a question of 1–600 characters','error')
                return redirect(url_for('assistant_page'))
            payload=make_reply(message,session.get('language','ar'),request.form.get('intent'))
            db().execute('INSERT INTO assistant_messages(user_id,role,message) VALUES (?,?,?)',(g.user['id'],'user',message))
            db().execute('INSERT INTO assistant_messages(user_id,role,message,links) VALUES (?,?,?,?)',
                         (g.user['id'],'bot',payload['reply'],json.dumps(payload['links'],ensure_ascii=False)))
            db().execute('DELETE FROM assistant_messages WHERE user_id=? AND id NOT IN (SELECT id FROM assistant_messages WHERE user_id=? ORDER BY id DESC LIMIT 24)',(g.user['id'],g.user['id']))
            db().commit()
            return redirect(url_for('assistant_page')+'#latestReply')
        rows=db().execute('SELECT * FROM assistant_messages WHERE user_id=? ORDER BY id',(g.user['id'],)).fetchall()
        history=[]
        for row in rows:
            try:links=json.loads(row['links'])
            except (ValueError,TypeError):links=[]
            history.append(dict(role=row['role'],message=row['message'],links=links))
        return render_template('assistant.html',history=history)

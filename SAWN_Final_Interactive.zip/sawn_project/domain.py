"""Additive upgrades, validated maintenance records, and device state."""
from datetime import date, datetime, timedelta, timezone

LOCAL_TZ = timezone(timedelta(hours=4))
DEVICE_STATE = """CASE
 WHEN EXISTS(SELECT 1 FROM tickets tx WHERE tx.device_id=d.id AND tx.status='قيد الصيانة') THEN 'قيد الصيانة'
 WHEN EXISTS(SELECT 1 FROM tickets tx WHERE tx.device_id=d.id AND tx.status='جديد') THEN 'بلاغ مفتوح'
 ELSE 'لا توجد بلاغات مفتوحة' END"""


DEVICE_CATEGORY = """CASE
 WHEN EXISTS(SELECT 1 FROM tickets tx WHERE tx.device_id=d.id AND tx.status='قيد الصيانة') THEN 'repairing'
 WHEN EXISTS(SELECT 1 FROM tickets tx WHERE tx.device_id=d.id AND tx.status='جديد') THEN 'open'
 WHEN EXISTS(SELECT 1 FROM tickets tx WHERE tx.device_id=d.id AND tx.status='مكتمل')
   OR EXISTS(SELECT 1 FROM maintenance_records mx WHERE mx.device_id=d.id) THEN 'completed'
 ELSE 'clear' END"""


def today():
    return datetime.now(LOCAL_TZ).date()


def upgrade(conn):
    changes = {
        'users': {'is_active':'INTEGER NOT NULL DEFAULT 1'},
        'devices': {'serial_number':"TEXT NOT NULL DEFAULT ''", 'location':"TEXT NOT NULL DEFAULT ''"},
        'schedules': {'service_code':'TEXT', 'is_active':'INTEGER NOT NULL DEFAULT 1'},
        'tickets': {'assigned_to':'INTEGER REFERENCES users(id)', 'created_by':'INTEGER REFERENCES users(id)',
                    'resolution':"TEXT NOT NULL DEFAULT ''", 'completed_at':'TEXT', 'maintenance_actions':"TEXT NOT NULL DEFAULT '[]'"},
    }
    for table, columns in changes.items():
        present={row[1] for row in conn.execute(f'PRAGMA table_info({table})')}
        for column, definition in columns.items():
            if column not in present:
                conn.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')
    from recurrence import LEGACY
    for label,code in LEGACY.items():conn.execute('UPDATE schedules SET service_code=? WHERE service_code IS NULL AND kind=?',(code,label))
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_device_serial ON devices(serial_number) WHERE serial_number!=''")
    conn.execute('CREATE INDEX IF NOT EXISTS idx_ticket_assignee ON tickets(assigned_to,status)')


def preserve_legacy(conn):
    conn.execute("""UPDATE tickets SET assigned_to=(SELECT u.id FROM users u WHERE u.role='technician'
        AND (u.username=tickets.technician COLLATE NOCASE OR u.display_name=tickets.technician) LIMIT 1)
        WHERE assigned_to IS NULL AND trim(technician)!=''""")
    conn.execute("UPDATE tickets SET completed_at=updated_at WHERE status='مكتمل' AND completed_at IS NULL")
    conn.execute("""INSERT INTO ticket_events(ticket_id,event_type,new_status,new_assigned_to,note,created_at)
        SELECT t.id,'legacy',t.status,t.assigned_to,'سجل موجود قبل التحديث؛ تفاصيل التغييرات السابقة غير متاحة',t.updated_at
        FROM tickets t WHERE NOT EXISTS(SELECT 1 FROM ticket_events e WHERE e.ticket_id=t.id)""")


def bounded(value, name, minimum=1, maximum=200):
    value=(value or '').strip()
    if not minimum <= len(value) <= maximum:
        raise ValueError(f'{name}: الطول المطلوب من {minimum} إلى {maximum} حرفًا')
    return value


def valid_date(value, required=False):
    if not value:
        if required: raise ValueError('يرجى تحديد تاريخ صحيح')
        return None
    try:
        return date.fromisoformat(value).isoformat()
    except (ValueError,TypeError):
        raise ValueError('صيغة التاريخ غير صحيحة') from None


def technician(conn, value, required=False):
    if not value:
        if required: raise ValueError('اختر فنيًا مسؤولًا عن البلاغ')
        return None
    try: user_id=int(value)
    except (TypeError,ValueError): raise ValueError('الفني غير صالح') from None
    row=conn.execute("SELECT id,display_name FROM users WHERE id=? AND role='technician' AND is_active=1",(user_id,)).fetchone()
    if not row: raise ValueError('اختر فنيًا نشطًا من القائمة')
    return row


def event(conn,ticket_id,actor_id,kind,old_status=None,new_status=None,old_assignee=None,new_assignee=None,note=''):
    cursor=conn.execute('''INSERT INTO ticket_events(ticket_id,actor_id,event_type,old_status,new_status,
                    old_assigned_to,new_assigned_to,note) VALUES (?,?,?,?,?,?,?,?)''',
                 (ticket_id,actor_id,kind,old_status,new_status,old_assignee,new_assignee,note))
    return cursor.lastrowid

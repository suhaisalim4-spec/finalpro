"""SAWN demonstration application. Local prototype; not an institutional deployment."""
import os, secrets, sqlite3
from pathlib import Path
from datetime import date, datetime, timedelta, timezone
from functools import wraps
from flask import Flask, render_template, redirect, url_for, request, session, flash, g, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.exceptions import HTTPException
from urllib.parse import urlsplit, unquote, urlencode, parse_qsl
from localization import translate

ROOT=Path(__file__).resolve().parent
app=Flask(__name__)
app.config['SECRET_KEY']=os.environ.get('SAWN_SECRET_KEY') or secrets.token_hex(32)
DB=Path(os.environ.get('SAWN_DB',str(ROOT/'sawn.db')))
STATUSES=['جديد','قيد الصيانة','مكتمل']

def db():
    if 'db' not in g:
        g.db=sqlite3.connect(DB)
        g.db.row_factory=sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    handle=g.pop('db',None)
    if handle: handle.close()

def setup():
    with app.app_context():
        db().executescript((ROOT/'schema.sql').read_text(encoding='utf-8'))
        for name,pwd,label,role in [('admin','Sawn@2026','مدير النظام','admin'),('tech','Tech@2026','أحمد - فني صيانة','technician'),('employee','Employee@2026','سالم - موظف','employee')]:
            db().execute('INSERT OR IGNORE INTO users(username,password_hash,display_name,role) VALUES (?,?,?,?)',(name,generate_password_hash(pwd),label,role))
        db().commit()

@app.before_request
def load_user():
    g.user=db().execute('SELECT * FROM users WHERE id=?',(session.get('uid',-1),)).fetchone()
    if request.endpoint == 'assistant_reply' and not g.user:
        return jsonify(error='authentication_required'),401
    if 'csrf' not in session: session['csrf']=secrets.token_hex(24)
    if request.method=='POST' and request.endpoint!='login':
        if (request.form.get('_csrf') or request.headers.get('X-CSRF-Token'))!=session.get('csrf'):
            return 'Invalid CSRF token',400

@app.after_request
def no_browser_scripts(response):
    response.headers['Content-Security-Policy'] = "script-src 'none'; object-src 'none'; base-uri 'self'"
    if response.mimetype == 'text/html':
        response.headers['Cache-Control'] = 'no-store'
    if (request.method == 'POST' and 300 <= response.status_code < 400
            and request.endpoint != 'logout'):
        session['skip_next_intro'] = True
    return response


@app.context_processor
def context():
    count=db().execute('SELECT count(*) FROM notifications WHERE user_id=? AND is_read=0',(g.user['id'],)).fetchone()[0] if g.user else 0
    skip_intro = session.pop('skip_next_intro', False)
    show_intro = request.method == 'GET' and not skip_intro
    navigation = [
        ('home','home','home'), ('devices','devices','devices'),
        ('tickets','tickets','tickets'), ('tasks','tasks','tasks'),
        ('maintenance','preventive','maintenance'), ('reports','reports','reports'),
    ]
    secondary_navigation = [
        ('team','staffDirectory','team'), ('technicians','technicians','technicians'),
        ('news','announcements','news'), ('support','support','support'),
        ('assistant_page','assistant','assistant'),
    ]
    if g.user and g.user['role']=='admin':
        secondary_navigation.append(('admin','admin','admin'))
    today_label = datetime.now(timezone(timedelta(hours=4))).strftime('%d / %m / %Y')
    return dict(csrf=session.get('csrf',''),current_user=g.user,unread=count,
                _=translate,lang=session.get('language','ar'),theme=session.get('theme','light'),
                navigation=navigation,secondary_navigation=secondary_navigation,
                nav_url=navigation_url,nav_link=navigation_link,
                intro_skip_url=url_for('navigate',to=request.full_path if request.query_string else request.path),
                show_intro=show_intro,today_label=today_label)


def navigation_link(target):
    return url_for('navigate', to=target)


def navigation_url(endpoint, **values):
    target=url_for(endpoint, **values)
    return target if endpoint=='static' else navigation_link(target)


@app.get('/go')
def navigate():
    target=request.args.get('to','/')
    try:
        parsed=urlsplit(target)
        if (not target.startswith('/') or target.startswith('//') or parsed.scheme or parsed.netloc
                or '\\' in unquote(target) or any(ord(c)<32 for c in target)):
            return 'Invalid navigation target',400
        endpoint,_=app.url_map.bind('localhost').match(parsed.path,method='GET')
    except (ValueError, HTTPException):
        # Werkzeug routing errors describe an unavailable internal page.
        return 'Invalid navigation target',400
    allowed={'home','login','devices','device_detail','tickets','tasks','maintenance',
             'reports','news','support','assistant_page','team','technicians','admin','notifications','search_page'}
    if endpoint not in allowed:
        return 'Invalid navigation target',400
    forwarded=dict(parse_qsl(parsed.query,keep_blank_values=True))
    forwarded.update({key:value for key,value in request.args.items() if key!='to'})
    query=urlencode(forwarded)
    destination=parsed.path+('?' + query if query else '')+('#' + parsed.fragment if parsed.fragment else '')
    session['skip_next_intro']=True
    return redirect(destination)


def session_preferences():
    return {key:session[key] for key in ('language','theme') if key in session}


def like_pattern(value):
    return '%' + value.replace('\\','\\\\').replace('%','\\%').replace('_','\\_') + '%'


@app.post('/preferences')
def preferences():
    language=request.form.get('language')
    theme=request.form.get('theme')
    if language in ('ar','en'):session['language']=language
    if theme in ('light','dark'):session['theme']=theme
    target=request.form.get('return_to','/')
    try:
        parsed=urlsplit(target)
    except ValueError:
        target='/'
        parsed=urlsplit(target)
    if (not target.startswith('/') or target.startswith('//') or parsed.scheme or parsed.netloc
            or '\\' in unquote(target) or any(ord(c)<32 for c in target)):
        target=url_for('home' if g.user else 'login')
    return redirect(target)


def login_required(fn):
    @wraps(fn)
    def inner(*args,**kwargs):
        if not g.user:return redirect(url_for('login'))
        return fn(*args,**kwargs)
    return inner

def admin_required(fn):
    @wraps(fn)
    @login_required
    def inner(*args,**kwargs):
        if g.user['role']!='admin':return 'لا تملك الصلاحية / Access denied',403
        return fn(*args,**kwargs)
    return inner

def log(action,detail=''):
    db().execute('INSERT INTO activity_log(actor_id,action,details) VALUES (?,?,?)',(g.user['id'] if g.user else None,action,detail))

def notify(uid,title,body,link='/tasks'):
    db().execute('INSERT INTO notifications(user_id,title,message,link) VALUES (?,?,?,?)',(uid,title,body,link))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        person=db().execute('SELECT * FROM users WHERE username=?',(request.form.get('username','').strip(),)).fetchone()
        if person and check_password_hash(person['password_hash'],request.form.get('password','')):
            saved=session_preferences();session.clear();session.update(saved)
            session['uid']=person['id'];session['csrf']=secrets.token_hex(24)
            return redirect(url_for('home'))
        flash('بيانات الدخول غير صحيحة / Invalid credentials','error')
    return render_template('login.html')

@app.post('/logout')
@login_required
def logout():
    db().execute('DELETE FROM assistant_messages WHERE user_id=?',(g.user['id'],))
    db().commit()
    saved=session_preferences();session.clear();session.update(saved)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def home():
    news=db().execute('SELECT * FROM announcements WHERE published=1 ORDER BY created_at DESC,id DESC LIMIT 4').fetchall()
    overview={
        'devices': db().execute('SELECT count(*) FROM devices').fetchone()[0],
        'open_tickets': db().execute("SELECT count(*) FROM tickets WHERE status!='مكتمل'").fetchone()[0],
        'completed_tickets': db().execute("SELECT count(*) FROM tickets WHERE status='مكتمل'").fetchone()[0],
        'my_tasks': db().execute("SELECT count(*) FROM tasks WHERE assigned_to=? AND status!='completed'",(g.user['id'],)).fetchone()[0],
    }
    return render_template('home.html',news=news,overview=overview)

@app.route('/devices',methods=['GET','POST'])
@login_required
def devices():
    if request.method=='POST':
        tag=request.form.get('asset_tag','').strip();name=request.form.get('name','').strip()
        if not tag or not name:flash('رقم الأصل واسم الجهاز مطلوبان','error')
        else:
            try:
                db().execute('INSERT INTO devices(asset_tag,name,model,department) VALUES (?,?,?,?)',(tag,name,request.form.get('model','').strip(),request.form.get('department','').strip()))
                log('device_created',tag);db().commit();flash('تمت إضافة الجهاز','success')
            except sqlite3.IntegrityError:flash('رقم الأصل مستخدم بالفعل','error')
        return redirect(url_for('devices'))
    query=request.args.get('q','').strip()[:100]
    if query:
        pattern=like_pattern(query)
        rows=db().execute("SELECT * FROM devices WHERE asset_tag LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' OR model LIKE ? ESCAPE '\\' OR department LIKE ? ESCAPE '\\' ORDER BY id DESC",(pattern,)*4).fetchall()
    else:
        rows=db().execute('SELECT * FROM devices ORDER BY id DESC').fetchall()
    return render_template('devices.html',rows=rows,query=query)

@app.route('/devices/<int:id>')
@login_required
def device_detail(id):
    dev=db().execute('SELECT * FROM devices WHERE id=?',(id,)).fetchone()
    if not dev:return 'Device not found',404
    tickets=db().execute('SELECT * FROM tickets WHERE device_id=? ORDER BY id DESC',(id,)).fetchall()
    schedules=db().execute('SELECT * FROM schedules WHERE device_id=? ORDER BY due_date',(id,)).fetchall()
    return render_template('device_detail.html',dev=dev,tickets=tickets,schedules=schedules)

@app.route('/tickets',methods=['GET','POST'])
@login_required
def tickets():
    if request.method=='POST':
        device_id=request.form.get('device_id',type=int);issue=request.form.get('issue','').strip()
        if not db().execute('SELECT 1 FROM devices WHERE id=?',(device_id,)).fetchone() or not issue:flash('حدد الجهاز ووصف المشكلة','error')
        else:
            db().execute('INSERT INTO tickets(device_id,issue,technician) VALUES (?,?,?)',(device_id,issue,request.form.get('technician','').strip()))
            log('ticket_created',issue[:80]);db().commit();flash('تم تسجيل بلاغ الصيانة','success')
        return redirect(url_for('tickets'))
    query=request.args.get('q','').strip()[:100]
    sql='SELECT t.*,d.asset_tag,d.name device_name FROM tickets t JOIN devices d ON d.id=t.device_id'
    if query:
        pattern=like_pattern(query)
        rows=db().execute(sql+" WHERE t.issue LIKE ? ESCAPE '\\' OR d.asset_tag LIKE ? ESCAPE '\\' OR d.name LIKE ? ESCAPE '\\' OR cast(t.id as text) LIKE ? ESCAPE '\\' ORDER BY t.id DESC",(pattern,)*4).fetchall()
    else:
        rows=db().execute(sql+' ORDER BY t.id DESC').fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    return render_template('tickets.html',rows=rows,devs=devs,statuses=STATUSES,query=query)

@app.post('/tickets/<int:id>/status')
@login_required
def ticket_status(id):
    status=request.form.get('status','')
    if status not in STATUSES:return 'Invalid status',400
    row=db().execute('SELECT * FROM tickets WHERE id=?',(id,)).fetchone()
    if not row:return 'Ticket not found',404
    if g.user['role']=='employee':return 'Access denied',403
    db().execute('UPDATE tickets SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,id));log('ticket_updated',str(id));db().commit()
    return redirect(url_for('tickets'))

@app.route('/technicians')
@login_required
def technicians():
    people=db().execute("SELECT * FROM users WHERE role='technician' ORDER BY id").fetchall()
    return render_template('technicians.html',people=people)

@app.get('/team')
@login_required
def team():
    people=db().execute("SELECT id,username,display_name,role FROM users ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'technician' THEN 1 ELSE 2 END,display_name").fetchall()
    return render_template('team.html',people=people)

@app.route('/tasks')
@login_required
def tasks():
    q='''SELECT t.*,u.display_name assignee,d.asset_tag FROM tasks t JOIN users u ON u.id=t.assigned_to LEFT JOIN devices d ON d.id=t.device_id'''
    if g.user['role']=='admin':rows=db().execute(q+' ORDER BY t.id DESC').fetchall()
    else:rows=db().execute(q+' WHERE t.assigned_to=? ORDER BY t.id DESC',(g.user['id'],)).fetchall()
    return render_template('tasks.html',rows=rows)

@app.route('/admin',methods=['GET','POST'])
@admin_required
def admin():
    if request.method=='POST':
        title=request.form.get('title','').strip();target=request.form.get('assigned_to',type=int)
        person=db().execute('SELECT * FROM users WHERE id=?',(target,)).fetchone()
        device_id=request.form.get('device_id',type=int) or None
        if not title or not person:flash('يرجى كتابة المهمة واختيار المستخدم','error')
        else:
            db().execute('''INSERT INTO tasks(title,description,device_id,assigned_to,assigned_by,priority,due_date) VALUES (?,?,?,?,?,?,?)''',(title,request.form.get('description','').strip(),device_id,target,g.user['id'],request.form.get('priority','normal'),request.form.get('due_date') or None))
            notify(target,'مهمة جديدة من الإدارة',title,'/tasks');log('task_assigned',title);db().commit();flash('تم إرسال المهمة والإشعار','success')
        return redirect(url_for('admin'))
    users=db().execute("SELECT * FROM users WHERE role!='admin'").fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    return render_template('admin.html',users=users,devs=devs)

@app.post('/tasks/<int:id>/status')
@login_required
def task_status(id):
    row=db().execute('SELECT * FROM tasks WHERE id=?',(id,)).fetchone()
    if not row:return 'Not found',404
    if row['assigned_to']!=g.user['id'] and g.user['role']!='admin':return 'Access denied',403
    status=request.form.get('status','')
    if status not in ('pending','in_progress','completed'):return 'Invalid status',400
    db().execute('UPDATE tasks SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,id))
    if row['assigned_to']!=row['assigned_by']:notify(row['assigned_by'],'تحديث حالة المهمة',f"{row['title']} — {status}",'/tasks')
    db().commit();return redirect(url_for('tasks'))

@app.route('/notifications')
@login_required
def notifications():
    rows=db().execute('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC',(g.user['id'],)).fetchall()
    due=db().execute('''SELECT s.*,d.asset_tag,d.name AS device_name FROM schedules s JOIN devices d ON d.id=s.device_id WHERE s.due_date<=date('now','+7 days') ORDER BY s.due_date LIMIT 5''').fetchall()
    return render_template('notifications.html',rows=rows,due=due)

@app.post('/notifications/read')
@login_required
def read_notifications():
    db().execute('UPDATE notifications SET is_read=1 WHERE user_id=?',(g.user['id'],));db().commit();return redirect(url_for('notifications'))

@app.route('/news',methods=['GET','POST'])
@login_required
def news():
    if request.method=='POST':
        if g.user['role']!='admin':return 'Access denied',403
        title=request.form.get('title_ar','').strip()
        if title:
            db().execute('INSERT INTO announcements(title_ar,title_en,body_ar,body_en,category,event_date) VALUES (?,?,?,?,?,?)',(title,request.form.get('title_en',''),request.form.get('body_ar',''),request.form.get('body_en',''),request.form.get('category','news'),request.form.get('event_date') or None));db().commit()
        return redirect(url_for('news'))
    rows=db().execute('SELECT * FROM announcements WHERE published=1 ORDER BY id DESC').fetchall()
    return render_template('news.html',rows=rows)

@app.route('/maintenance',methods=['GET','POST'])
@login_required
def maintenance():
    if request.method=='POST':
        if g.user['role']!='admin':return 'Access denied',403
        dev=request.form.get('device_id',type=int);kind=request.form.get('kind','').strip();due=request.form.get('due_date')
        if not dev or not kind or not due:flash('أكمل بيانات الجدولة','error')
        else:
            db().execute('INSERT INTO schedules(device_id,kind,due_date,interval_days,assigned_to) VALUES (?,?,?,?,?)',(dev,kind,due,max(1,request.form.get('interval_days',type=int) or 90),request.form.get('assigned_to',type=int) or None));db().commit()
        return redirect(url_for('maintenance'))
    rows=db().execute('SELECT s.*,d.name device_name,d.asset_tag FROM schedules s JOIN devices d ON d.id=s.device_id ORDER BY s.due_date').fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    users=db().execute("SELECT * FROM users WHERE role='technician'").fetchall()
    return render_template('maintenance.html',rows=rows,devs=devs,users=users,today=date.today().isoformat())

@app.post('/maintenance/<int:id>/done')
@login_required
def maintenance_done(id):
    row=db().execute('SELECT * FROM schedules WHERE id=?',(id,)).fetchone()
    if not row:return 'Not found',404
    if g.user['role']!='admin' and row['assigned_to']!=g.user['id']:return 'Access denied',403
    today=date.today();next_due=today+timedelta(days=row['interval_days'])
    db().execute('UPDATE schedules SET last_done=?,due_date=? WHERE id=?',(today.isoformat(),next_due.isoformat(),id))
    log('preventive_maintenance_done',str(id));db().commit();return redirect(url_for('maintenance'))

@app.route('/reports')
@login_required
def reports():
    start=request.args.get('start') or (date.today()-timedelta(days=date.today().weekday())).isoformat()
    try:begin=date.fromisoformat(start)
    except ValueError:begin=date.today()
    end=begin+timedelta(days=7)
    all_tickets=db().execute('''SELECT t.*,d.asset_tag FROM tickets t JOIN devices d ON d.id=t.device_id WHERE date(t.created_at)>=? AND date(t.created_at)<? ORDER BY t.id DESC''',(begin.isoformat(),end.isoformat())).fetchall()
    devices_count=db().execute('SELECT count(*) FROM devices WHERE date(created_at)>=? AND date(created_at)<?',(begin.isoformat(),end.isoformat())).fetchone()[0]
    tasks=db().execute('''SELECT t.*,u.display_name FROM tasks t JOIN users u ON u.id=t.assigned_to WHERE (date(t.due_date)>=? AND date(t.due_date)<?) OR (t.status!='completed' AND t.due_date IS NULL) ORDER BY t.due_date,t.id''',(begin.isoformat(),end.isoformat())).fetchall()
    upkeep=db().execute('SELECT s.*,d.asset_tag FROM schedules s JOIN devices d ON d.id=s.device_id WHERE s.due_date>=? AND s.due_date<?',(begin.isoformat(),end.isoformat())).fetchall()
    return render_template('reports.html',start=begin.isoformat(),end=(end-timedelta(days=1)).isoformat(),tickets=all_tickets,devices_count=devices_count,tasks=tasks,upkeep=upkeep)

@app.route('/support',methods=['GET','POST'])
@login_required
def support():
    if request.method=='POST':
        subject=request.form.get('subject','').strip();message=request.form.get('message','').strip()
        if subject and message:
            db().execute('INSERT INTO support_requests(user_id,subject,message) VALUES (?,?,?)',(g.user['id'],subject,message));db().commit();flash('تم إرسال طلب الدعم','success')
        else:flash('املأ جميع الحقول','error')
        return redirect(url_for('support'))
    return render_template('support.html')

@app.get('/search')
@login_required
def search_page():
    query=request.args.get('q','').strip()[:100]
    results=[]
    if query:
        pattern=like_pattern(query)
        devices=db().execute("SELECT id,asset_tag,name FROM devices WHERE asset_tag LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT 20",(pattern,pattern)).fetchall()
        tickets=db().execute("SELECT t.id,t.issue,d.asset_tag FROM tickets t JOIN devices d ON d.id=t.device_id WHERE t.issue LIKE ? ESCAPE '\\' OR cast(t.id as text) LIKE ? ESCAPE '\\' OR d.asset_tag LIKE ? ESCAPE '\\' ORDER BY t.id DESC LIMIT 20",(pattern,)*3).fetchall()
        results.extend({'title':row['asset_tag']+' · '+row['name'],'url':url_for('device_detail',id=row['id']),'kind':'devices'} for row in devices)
        results.extend({'title':'#'+str(row['id'])+' · '+row['asset_tag']+' · '+row['issue'],'url':url_for('tickets',q=str(row['id'])),'kind':'tickets'} for row in tickets)
    return render_template('search.html',query=query,results=results)


from assistant import register_assistant
register_assistant(app, db, login_required)

setup()
if __name__=='__main__':app.run(debug=True)

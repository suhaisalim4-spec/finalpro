"""SAWN demonstration application. Local prototype; not an institutional deployment."""
import os, secrets, sqlite3
from pathlib import Path
from datetime import date, datetime, timedelta, timezone
from functools import wraps
from flask import Flask, render_template, redirect, url_for, request, session, flash, g, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.exceptions import HTTPException
from urllib.parse import urlsplit, unquote, urlencode, parse_qsl
from localization import translate
from domain import upgrade, preserve_legacy, bounded, valid_date, technician, event, DEVICE_STATE, today
from automation import start_worker, run_due, generate_due_reports, report_data, before_upgrade_backup

ROOT=Path(__file__).resolve().parent
app=Flask(__name__)
app.config['SECRET_KEY']=os.environ.get('SAWN_SECRET_KEY') or secrets.token_hex(32)
DB=Path(os.environ.get('SAWN_DB',str(ROOT/'sawn.db')))
STATUSES=['جديد','قيد الصيانة','مكتمل']

def db():
    if 'db' not in g:
        g.db=sqlite3.connect(DB)
        g.db.row_factory=sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    handle=g.pop('db',None)
    if handle: handle.close()

def setup():
    before_upgrade_backup(DB)
    with app.app_context():
        db().executescript((ROOT/'schema.sql').read_text(encoding='utf-8'))
        upgrade(db())
        for name,pwd,label,role in [('admin','Sawn@2026','مدير النظام','admin'),('tech','Tech@2026','أحمد - فني صيانة','technician'),('employee','Employee@2026','سالم - موظف','employee')]:
            db().execute('INSERT OR IGNORE INTO users(username,password_hash,display_name,role) VALUES (?,?,?,?)',(name,generate_password_hash(pwd),label,role))
        preserve_legacy(db())
        db().commit()

@app.before_request
def load_user():
    start_worker(app,DB)
    g.user=db().execute('SELECT * FROM users WHERE id=? AND is_active=1',(session.get('uid',-1),)).fetchone()
    if request.endpoint == 'assistant_reply' and not g.user:
        return jsonify(error='authentication_required'),401
    if 'csrf' not in session: session['csrf']=secrets.token_hex(24)
    if request.method=='POST' and request.endpoint!='login':
        if (request.form.get('_csrf') or request.headers.get('X-CSRF-Token'))!=session.get('csrf'):
            return 'Invalid CSRF token',400

@app.after_request
def no_browser_scripts(response):
    response.headers['Content-Security-Policy'] = "script-src 'none'; object-src 'none'; base-uri 'self'"
    if response.mimetype == 'text/html':
        response.headers['Cache-Control'] = 'no-store'
    if (request.method == 'POST' and 300 <= response.status_code < 400
            and request.endpoint != 'logout'):
        session['skip_next_intro'] = True
    return response


@app.context_processor
def context():
    count=db().execute('SELECT count(*) FROM notifications WHERE user_id=? AND is_read=0',(g.user['id'],)).fetchone()[0] if g.user else 0
    skip_intro = session.pop('skip_next_intro', False)
    show_intro = request.method == 'GET' and not skip_intro
    navigation = [
        ('home','home','home'), ('devices','devices','devices'),
        ('tickets','tickets','tickets'), ('tasks','tasks','tasks'),
        ('maintenance','preventive','maintenance'), ('reports','reports','reports'),
    ]
    secondary_navigation = [
        ('team','staffDirectory','team'), ('technicians','technicians','technicians'),
        ('news','announcements','news'), ('support','support','support'),
        ('assistant_page','assistant','assistant'),
    ]
    if g.user and g.user['role']=='admin':
        secondary_navigation.extend([('admin','admin','admin'),('users','userAccounts','team'),('backups','backups','admin')])
    else:
        navigation=[item for item in navigation if item[0]!='reports']
    today_label = datetime.now(timezone(timedelta(hours=4))).strftime('%d / %m / %Y')
    return dict(csrf=session.get('csrf',''),current_user=g.user,unread=count,
                _=translate,lang=session.get('language','ar'),theme=session.get('theme','light'),
                navigation=navigation,secondary_navigation=secondary_navigation,
                nav_url=navigation_url,nav_link=navigation_link,
                show_intro=show_intro,today_label=today_label)


def navigation_link(target):
    return url_for('navigate', to=target)


def navigation_url(endpoint, **values):
    target=url_for(endpoint, **values)
    return target if endpoint=='static' else navigation_link(target)


@app.get('/go')
def navigate():
    target=request.args.get('to','/')
    try:
        parsed=urlsplit(target)
        if (not target.startswith('/') or target.startswith('//') or parsed.scheme or parsed.netloc
                or '\\' in unquote(target) or any(ord(c)<32 for c in target)):
            return 'Invalid navigation target',400
        endpoint,_=app.url_map.bind('localhost').match(parsed.path,method='GET')
    except (ValueError, HTTPException):
        # Werkzeug routing errors describe an unavailable internal page.
        return 'Invalid navigation target',400
    allowed={'home','login','devices','device_detail','tickets','tasks','maintenance',
             'reports','report_archive','news','support','assistant_page','team','technicians','admin','users','backups','notifications','search_page','ticket_detail'}
    if endpoint not in allowed:
        return 'Invalid navigation target',400
    forwarded=dict(parse_qsl(parsed.query,keep_blank_values=True))
    forwarded.update({key:value for key,value in request.args.items() if key!='to'})
    query=urlencode(forwarded)
    destination=parsed.path+('?' + query if query else '')+('#' + parsed.fragment if parsed.fragment else '')
    session['skip_next_intro']=True
    return redirect(destination)


def session_preferences():
    return {key:session[key] for key in ('language','theme') if key in session}


def like_pattern(value):
    return '%' + value.replace('\\','\\\\').replace('%','\\%').replace('_','\\_') + '%'


@app.post('/preferences')
def preferences():
    language=request.form.get('language')
    theme=request.form.get('theme')
    if language in ('ar','en'):session['language']=language
    if theme in ('light','dark'):session['theme']=theme
    target=request.form.get('return_to','/')
    try:
        parsed=urlsplit(target)
    except ValueError:
        target='/'
        parsed=urlsplit(target)
    if (not target.startswith('/') or target.startswith('//') or parsed.scheme or parsed.netloc
            or '\\' in unquote(target) or any(ord(c)<32 for c in target)):
        target=url_for('home' if g.user else 'login')
    return redirect(target)


def login_required(fn):
    @wraps(fn)
    def inner(*args,**kwargs):
        if not g.user:return redirect(url_for('login'))
        return fn(*args,**kwargs)
    return inner

def admin_required(fn):
    @wraps(fn)
    @login_required
    def inner(*args,**kwargs):
        if g.user['role']!='admin':return 'لا تملك الصلاحية / Access denied',403
        return fn(*args,**kwargs)
    return inner

def log(action,detail=''):
    db().execute('INSERT INTO activity_log(actor_id,action,details) VALUES (?,?,?)',(g.user['id'] if g.user else None,action,detail))

def notify(uid,title,body,link='/tasks'):
    db().execute('INSERT INTO notifications(user_id,title,message,link) VALUES (?,?,?,?)',(uid,title,body,link))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        person=db().execute('SELECT * FROM users WHERE username=? AND is_active=1',(request.form.get('username','').strip(),)).fetchone()
        if person and check_password_hash(person['password_hash'],request.form.get('password','')):
            saved=session_preferences();session.clear();session.update(saved)
            session['uid']=person['id'];session['csrf']=secrets.token_hex(24)
            return redirect(url_for('home'))
        flash('بيانات الدخول غير صحيحة / Invalid credentials','error')
    return render_template('login.html')

@app.post('/logout')
@login_required
def logout():
    db().execute('DELETE FROM assistant_messages WHERE user_id=?',(g.user['id'],))
    db().commit()
    saved=session_preferences();session.clear();session.update(saved)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def home():
    news=db().execute('SELECT * FROM announcements WHERE published=1 ORDER BY created_at DESC,id DESC LIMIT 4').fetchall()
    condition,params=visibility('t')
    counts=db().execute("SELECT count(*) total, sum(status='جديد') new_count, sum(status='قيد الصيانة') repairing, sum(status='مكتمل') completed FROM tickets t WHERE "+condition,params).fetchone()
    overview={'devices':db().execute('SELECT count(*) FROM devices').fetchone()[0],
              'open_tickets':(counts['new_count'] or 0)+(counts['repairing'] or 0),
              'repairing':counts['repairing'] or 0,'completed_tickets':counts['completed'] or 0}
    recent=db().execute("SELECT t.*,d.asset_tag,COALESCE(u.display_name,t.technician) assignee FROM tickets t JOIN devices d ON d.id=t.device_id LEFT JOIN users u ON u.id=t.assigned_to WHERE "+condition+' ORDER BY t.updated_at DESC,t.id DESC LIMIT 5',params).fetchall()
    mine=db().execute("SELECT * FROM tasks WHERE assigned_to=? AND status!='completed' ORDER BY due_date IS NULL,due_date,id DESC LIMIT 4",(g.user['id'],)).fetchall()
    workload=[]
    if g.user['role']=='admin':
        workload=db().execute("SELECT u.id,u.display_name,count(t.id) open_count FROM users u LEFT JOIN tickets t ON t.assigned_to=u.id AND t.status!='مكتمل' WHERE u.role='technician' AND u.is_active=1 GROUP BY u.id ORDER BY open_count DESC,u.display_name").fetchall()
    return render_template('home.html',news=news,overview=overview,recent=recent,my_tasks=mine,workload=workload)


def visibility(alias='t'):
    if g.user['role']=='admin':return '1=1',()
    if g.user['role']=='technician':return f'({alias}.assigned_to=? OR {alias}.created_by=?)',(g.user['id'],g.user['id'])
    return f'{alias}.created_by=?',(g.user['id'],)


@app.route('/devices',methods=['GET','POST'])
@login_required
def devices():
    if request.method=='POST':
        try:
            tag=bounded(request.form.get('asset_tag'),'رقم الأصل',1,60)
            name=bounded(request.form.get('name'),'اسم الجهاز',2,150)
            model=bounded(request.form.get('model'),'الطراز',0,100)
            department=bounded(request.form.get('department'),'القسم',0,100)
            serial=bounded(request.form.get('serial_number'),'الرقم التسلسلي',0,100)
            location=bounded(request.form.get('location'),'الموقع',0,150)
            db().execute('INSERT INTO devices(asset_tag,name,model,department,serial_number,location) VALUES (?,?,?,?,?,?)',(tag,name,model,department,serial,location))
            log('device_created',tag);db().commit();flash('تمت إضافة الجهاز','success')
        except ValueError as exc:flash(str(exc),'error')
        except sqlite3.IntegrityError:
            db().rollback();flash('رقم الأصل أو الرقم التسلسلي مستخدم؛ لم تتم إضافة سجل مكرر','error')
        return redirect(url_for('devices'))
    query=request.args.get('q','').strip()[:100]
    sql='SELECT d.*, '+DEVICE_STATE+' device_state FROM devices d'
    if query:
        pattern=like_pattern(query)
        rows=db().execute(sql+" WHERE d.asset_tag LIKE ? ESCAPE '\\' OR d.name LIKE ? ESCAPE '\\' OR d.model LIKE ? ESCAPE '\\' OR d.department LIKE ? ESCAPE '\\' OR d.serial_number LIKE ? ESCAPE '\\' ORDER BY d.id DESC",(pattern,)*5).fetchall()
    else:rows=db().execute(sql+' ORDER BY d.id DESC').fetchall()
    return render_template('devices.html',rows=rows,query=query)


@app.route('/devices/<int:id>')
@login_required
def device_detail(id):
    dev=db().execute('SELECT d.*, '+DEVICE_STATE+' device_state FROM devices d WHERE d.id=?',(id,)).fetchone()
    if not dev:return 'Device not found',404
    scope,params=visibility('t')
    tickets=db().execute('SELECT t.*,COALESCE(u.display_name,t.technician) assignee FROM tickets t LEFT JOIN users u ON u.id=t.assigned_to WHERE t.device_id=? AND '+scope+' ORDER BY t.id DESC',(id,)+params).fetchall()
    events=db().execute('SELECT e.*,u.display_name actor,t.issue FROM ticket_events e JOIN tickets t ON t.id=e.ticket_id LEFT JOIN users u ON u.id=e.actor_id WHERE t.device_id=? AND '+scope+' ORDER BY e.id DESC',(id,)+params).fetchall()
    schedules=db().execute('SELECT * FROM schedules WHERE device_id=? ORDER BY due_date',(id,)).fetchall()
    return render_template('device_detail.html',dev=dev,tickets=tickets,schedules=schedules,events=events)


@app.route('/tickets',methods=['GET','POST'])
@login_required
def tickets():
    if request.method=='POST':
        try:
            device_id=request.form.get('device_id',type=int)
            if not db().execute('SELECT 1 FROM devices WHERE id=?',(device_id,)).fetchone():raise ValueError('اختر جهازًا مسجلًا')
            issue=bounded(request.form.get('issue'),'وصف المشكلة',3,3000)
            assignee=technician(db(),request.form.get('assigned_to'),required=True)
            db().execute('BEGIN IMMEDIATE')
            duplicate=db().execute("SELECT id FROM tickets WHERE device_id=? AND lower(trim(issue))=lower(?) AND status!='مكتمل'",(device_id,issue)).fetchone()
            if duplicate:
                db().rollback();flash('يوجد بلاغ مفتوح بنفس المشكلة لهذا الجهاز؛ لم نكرر السجل','error')
                return redirect(url_for('ticket_detail',id=duplicate['id'])) if g.user['role']=='admin' else redirect(url_for('tickets'))
            cursor=db().execute('INSERT INTO tickets(device_id,issue,technician,assigned_to,created_by) VALUES (?,?,?,?,?)',(device_id,issue,assignee['display_name'],assignee['id'],g.user['id']))
            event(db(),cursor.lastrowid,g.user['id'],'created',new_status='جديد',new_assignee=assignee['id'],note=issue)
            notify(assignee['id'],'بلاغ صيانة مسند إليك',issue,'/tickets/'+str(cursor.lastrowid))
            log('ticket_created',str(cursor.lastrowid));db().commit();flash('تم تسجيل البلاغ وإشعار الفني المسؤول','success')
        except ValueError as exc:
            db().rollback();flash(str(exc),'error')
        return redirect(url_for('tickets'))
    query=request.args.get('q','').strip()[:100]
    scope,params=visibility('t')
    sql='SELECT t.*,d.asset_tag,d.name device_name,COALESCE(u.display_name,t.technician) assignee FROM tickets t JOIN devices d ON d.id=t.device_id LEFT JOIN users u ON u.id=t.assigned_to WHERE '+scope
    if query:
        pattern=like_pattern(query)
        sql+=" AND (t.issue LIKE ? ESCAPE '\\' OR d.asset_tag LIKE ? ESCAPE '\\' OR d.name LIKE ? ESCAPE '\\' OR cast(t.id as text) LIKE ? ESCAPE '\\')"
        params=params+(pattern,)*4
    rows=db().execute(sql+' ORDER BY t.id DESC',params).fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    technicians=db().execute("SELECT id,display_name FROM users WHERE role='technician' AND is_active=1 ORDER BY display_name").fetchall()
    return render_template('tickets.html',rows=rows,devs=devs,statuses=STATUSES,query=query,technicians=technicians)


@app.post('/tickets/<int:id>/status')
@login_required
def ticket_status(id):
    row=db().execute('SELECT * FROM tickets WHERE id=?',(id,)).fetchone()
    if not row:return 'Ticket not found',404
    if g.user['role']!='admin' and not (g.user['role']=='technician' and row['assigned_to']==g.user['id']):return 'Access denied',403
    status=request.form.get('status','')
    if status not in STATUSES:return 'Invalid status',400
    note=request.form.get('note','').strip()
    resolution=request.form.get('resolution','').strip()
    if len(note)>3000 or len(resolution)>3000:return 'Notes too long',400
    if status=='مكتمل' and len(resolution)<3:
        flash('اكتب ملخص الإصلاح قبل إكمال البلاغ','error');return redirect(url_for('ticket_detail',id=id))
    if status==row['status'] and not note and (status!='مكتمل' or resolution==row['resolution']):return redirect(url_for('ticket_detail',id=id))
    completed=row['completed_at'] if row['status']=='مكتمل' and status=='مكتمل' else (datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S') if status=='مكتمل' else None)
    db().execute('UPDATE tickets SET status=?,resolution=?,completed_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,resolution if status=='مكتمل' else '' if row['status']=='مكتمل' else row['resolution'],completed,id))
    event(db(),id,g.user['id'],'status' if status!=row['status'] else 'note',row['status'],status,note=(resolution+('\n'+note if note else '')) if status=='مكتمل' else note)
    if row['created_by'] and row['created_by']!=g.user['id']:notify(row['created_by'],'تحديث بلاغ الصيانة',f"#{id} — {status}",'/tickets/'+str(id))
    log('ticket_updated',str(id));db().commit()
    return redirect(url_for('ticket_detail',id=id))


@app.route('/technicians')
@login_required
def technicians():
    people=db().execute("SELECT * FROM users WHERE role='technician' AND is_active=1 ORDER BY id").fetchall()
    return render_template('technicians.html',people=people)

@app.get('/team')
@login_required
def team():
    people=db().execute("SELECT id,username,display_name,role FROM users WHERE is_active=1 ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'technician' THEN 1 ELSE 2 END,display_name").fetchall()
    return render_template('team.html',people=people)

@app.route('/tasks')
@login_required
def tasks():
    q='''SELECT t.*,u.display_name assignee,d.asset_tag FROM tasks t JOIN users u ON u.id=t.assigned_to LEFT JOIN devices d ON d.id=t.device_id'''
    if g.user['role']=='admin':rows=db().execute(q+' ORDER BY t.id DESC').fetchall()
    else:rows=db().execute(q+' WHERE t.assigned_to=? ORDER BY t.id DESC',(g.user['id'],)).fetchall()
    return render_template('tasks.html',rows=rows)

@app.route('/admin',methods=['GET','POST'])
@admin_required
def admin():
    if request.method=='POST':
        try:
            title=bounded(request.form.get('title'),'عنوان المهمة',3,200)
            description=bounded(request.form.get('description'),'تفاصيل المهمة',0,3000)
            target=request.form.get('assigned_to',type=int)
            person=db().execute("SELECT * FROM users WHERE id=? AND is_active=1 AND role!='admin'",(target,)).fetchone()
            if not person:raise ValueError('اختر مستخدمًا نشطًا')
            device_id=request.form.get('device_id',type=int) or None
            if device_id and not db().execute('SELECT 1 FROM devices WHERE id=?',(device_id,)).fetchone():raise ValueError('الجهاز غير موجود')
            priority=request.form.get('priority','normal')
            if priority not in ('normal','high','urgent'):raise ValueError('الأولوية غير صحيحة')
            due=valid_date(request.form.get('due_date'))
            db().execute('INSERT INTO tasks(title,description,device_id,assigned_to,assigned_by,priority,due_date) VALUES (?,?,?,?,?,?,?)',(title,description,device_id,target,g.user['id'],priority,due))
            notify(target,'مهمة جديدة من الإدارة',title,'/tasks');log('task_assigned',title);db().commit();flash('تم إرسال المهمة والإشعار','success')
        except ValueError as exc:flash(str(exc),'error')
        return redirect(url_for('admin'))
    users=db().execute("SELECT * FROM users WHERE role!='admin' AND is_active=1").fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    return render_template('admin.html',users=users,devs=devs)

@app.post('/tasks/<int:id>/status')
@login_required
def task_status(id):
    row=db().execute('SELECT * FROM tasks WHERE id=?',(id,)).fetchone()
    if not row:return 'Not found',404
    if row['assigned_to']!=g.user['id'] and g.user['role']!='admin':return 'Access denied',403
    status=request.form.get('status','')
    if status not in ('pending','in_progress','completed'):return 'Invalid status',400
    db().execute('UPDATE tasks SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,id))
    if row['assigned_to']!=row['assigned_by']:notify(row['assigned_by'],'تحديث حالة المهمة',f"{row['title']} — {status}",'/tasks')
    db().commit();return redirect(url_for('tasks'))

@app.route('/notifications')
@login_required
def notifications():
    rows=db().execute('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC',(g.user['id'],)).fetchall()
    due=db().execute('''SELECT s.*,d.asset_tag,d.name AS device_name FROM schedules s JOIN devices d ON d.id=s.device_id WHERE s.due_date<=date('now','+4 hours','+7 days') ORDER BY s.due_date LIMIT 5''').fetchall()
    return render_template('notifications.html',rows=rows,due=due)

@app.post('/notifications/read')
@login_required
def read_notifications():
    db().execute('UPDATE notifications SET is_read=1 WHERE user_id=?',(g.user['id'],));db().commit();return redirect(url_for('notifications'))

@app.route('/news',methods=['GET','POST'])
@login_required
def news():
    if request.method=='POST':
        if g.user['role']!='admin':return 'Access denied',403
        try:
            title=bounded(request.form.get('title_ar'),'عنوان الإعلان',3,200)
            title_en=bounded(request.form.get('title_en'),'العنوان الإنجليزي',0,200)
            body=bounded(request.form.get('body_ar'),'الإعلان',0,5000)
            body_en=bounded(request.form.get('body_en'),'الإعلان الإنجليزي',0,5000)
            category=request.form.get('category','news')
            if category not in ('news','workshop','maintenance'):raise ValueError('التصنيف غير صالح')
            due=valid_date(request.form.get('event_date'))
            db().execute('INSERT INTO announcements(title_ar,title_en,body_ar,body_en,category,event_date) VALUES (?,?,?,?,?,?)',(title,title_en,body,body_en,category,due))
            log('announcement_created',title);db().commit()
        except ValueError as exc:flash(str(exc),'error')
        return redirect(url_for('news'))
    rows=db().execute('SELECT * FROM announcements WHERE published=1 ORDER BY id DESC').fetchall()
    return render_template('news.html',rows=rows)

@app.route('/maintenance',methods=['GET','POST'])
@login_required
def maintenance():
    if request.method=='POST':
        if g.user['role']!='admin':return 'Access denied',403
        try:
            dev=request.form.get('device_id',type=int)
            if not db().execute('SELECT 1 FROM devices WHERE id=?',(dev,)).fetchone():raise ValueError('اختر جهازًا مسجلًا')
            kind=bounded(request.form.get('kind'),'نوع الصيانة',3,200)
            due=valid_date(request.form.get('due_date'),True)
            interval=request.form.get('interval_days',type=int)
            if interval is None or not 1<=interval<=3650:raise ValueError('الفاصل بين الصيانات يجب أن يكون من 1 إلى 3650 يومًا')
            assignee=technician(db(),request.form.get('assigned_to'))
            db().execute('INSERT INTO schedules(device_id,kind,due_date,interval_days,assigned_to) VALUES (?,?,?,?,?)',(dev,kind,due,interval,assignee['id'] if assignee else None))
            log('maintenance_scheduled',str(dev));db().commit();flash('تم حفظ موعد الصيانة','success')
        except ValueError as exc:flash(str(exc),'error')
        return redirect(url_for('maintenance'))
    rows=db().execute('SELECT s.*,d.name device_name,d.asset_tag FROM schedules s JOIN devices d ON d.id=s.device_id ORDER BY s.due_date').fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    users=db().execute("SELECT * FROM users WHERE role='technician' AND is_active=1").fetchall()
    return render_template('maintenance.html',rows=rows,devs=devs,users=users,today=today().isoformat())

@app.post('/maintenance/<int:id>/done')
@login_required
def maintenance_done(id):
    row=db().execute('SELECT * FROM schedules WHERE id=?',(id,)).fetchone()
    if not row:return 'Not found',404
    if g.user['role']!='admin' and row['assigned_to']!=g.user['id']:return 'Access denied',403
    current_day=today();next_due=current_day+timedelta(days=row['interval_days'])
    db().execute('UPDATE schedules SET last_done=?,due_date=? WHERE id=?',(current_day.isoformat(),next_due.isoformat(),id))
    log('preventive_maintenance_done',str(id));db().commit();return redirect(url_for('maintenance'))

@app.route('/reports')
@admin_required
def reports():
    start=request.args.get('start') or (today()-timedelta(days=today().weekday())).isoformat()
    try:begin=date.fromisoformat(start)
    except ValueError:begin=today()-timedelta(days=today().weekday())
    payload=report_data(db(),begin)
    saved=db().execute('SELECT id,week_start,week_end,generated_at FROM weekly_reports ORDER BY week_start DESC LIMIT 52').fetchall()
    return render_template('reports.html',report=payload,saved=saved,snapshot=None)

@app.route('/support',methods=['GET','POST'])
@login_required
def support():
    if request.method=='POST':
        subject=request.form.get('subject','').strip();message=request.form.get('message','').strip()
        if subject and message:
            db().execute('INSERT INTO support_requests(user_id,subject,message) VALUES (?,?,?)',(g.user['id'],subject,message));db().commit();flash('تم إرسال طلب الدعم','success')
        else:flash('املأ جميع الحقول','error')
        return redirect(url_for('support'))
    return render_template('support.html')

@app.get('/search')
@login_required
def search_page():
    query=request.args.get('q','').strip()[:100]
    results=[]
    if query:
        pattern=like_pattern(query)
        devices=db().execute("SELECT id,asset_tag,name FROM devices WHERE asset_tag LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT 20",(pattern,pattern)).fetchall()
        scope,params=visibility('t')
        tickets=db().execute("SELECT t.id,t.issue,d.asset_tag FROM tickets t JOIN devices d ON d.id=t.device_id WHERE "+scope+" AND (t.issue LIKE ? ESCAPE '\\' OR cast(t.id as text) LIKE ? ESCAPE '\\' OR d.asset_tag LIKE ? ESCAPE '\\') ORDER BY t.id DESC LIMIT 20",params+(pattern,)*3).fetchall()
        results.extend({'title':row['asset_tag']+' · '+row['name'],'url':url_for('device_detail',id=row['id']),'kind':'devices'} for row in devices)
        results.extend({'title':'#'+str(row['id'])+' · '+row['asset_tag']+' · '+row['issue'],'url':url_for('ticket_detail',id=row['id']),'kind':'tickets'} for row in tickets)
    return render_template('search.html',query=query,results=results)


from assistant import register_assistant
register_assistant(app, db, login_required)

@app.template_filter('local_time')
def local_time(value):
    if not value:return '—'
    try:
        parsed=datetime.fromisoformat(value)
        if parsed.tzinfo is None:parsed=parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone(timedelta(hours=4))).strftime('%Y-%m-%d %H:%M')
    except (ValueError,TypeError):return value

from workflows import register_workflows
register_workflows(app,db,login_required,admin_required,log,notify,visibility,lambda:DB)

@app.cli.command('run-automation')
def automation_command():
    count,path=run_due(DB)
    print(f'Generated {count} weekly reports; backup: {path.name}')

setup()
if __name__=='__main__':
    start_worker(app,DB)
    app.run(port=int(os.environ.get('SAWN_PORT','5000')),debug=False,use_reloader=False)
